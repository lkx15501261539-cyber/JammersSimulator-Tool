"""Controller-level regressions for accepted actions and frozen C/U budgets."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import run


class ControllerTests(unittest.TestCase):
    def make_controller(self, sources):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        cfg = json.loads((Path(run.__file__).parent/'config.json').read_text())
        backend = run.OfflineBackend({'seed': 17, 'sources': sources})
        client = run.JournalClient(backend, tmp.name, 'test-v2', cfg)
        self.addCleanup(client.close)
        client.call('/enter')
        return run.Controller(client, cfg), backend

    def test_origin_full_scan_and_near_clear(self):
        c, backend = self.make_controller([{'channel': 5, 'position':[1,0], 'radius':1000}])
        c.scan_anchor(0)
        measured = [e['channel'] for e in c.events if e['kind']=='measure']
        self.assertEqual(measured, list(range(1,21)))
        self.assertEqual(c.channels[5].state, 'CLEARED')
        self.assertEqual(c.client.channel, 20)
        self.assertEqual(c.client.virtual_time, 124)
        self.assertTrue(all(ch.anchors == [0] for ch in c.channels.values()))

    def test_current_channel_first_only_unknown(self):
        c, _ = self.make_controller([])
        c.client.channel = 7
        c.client.backend._channel = 7
        c.channels[2].state='FOUND'
        c.scan_anchor(1)
        measured = [e['channel'] for e in c.events if e['kind']=='measure']
        self.assertEqual(measured[0], 7)
        self.assertEqual(measured[1:], [k for k in range(1,21) if k not in (2,7)])
        self.assertEqual(c.client.switches, 18)

    def test_absent_requires_each_channel_all_seven(self):
        c, _ = self.make_controller([])
        for i in range(6): c.scan_anchor(i)
        self.assertTrue(all(ch.state=='UNKNOWN' for ch in c.channels.values()))
        c.scan_anchor(6)
        self.assertTrue(all(ch.state=='EMPTY_CERTIFIED' for ch in c.channels.values()))
        self.assertEqual(c.client.measures, 140)
        self.assertEqual(c.pending_searches(), [])

    def test_optical_failures_do_not_resume_radio_or_change_channel(self):
        c, _ = self.make_controller([{'channel':2, 'position':[100,0], 'radius':1000}])
        c.channels[2].state='FOUND'
        plan={'kind':'optical','points':np.array([[0.,0.],[100.,0.]]),
              'certificate':{'test':True},'bound_s':28.}
        c.execute_optical(2,plan)
        self.assertEqual(c.client.measures,0)
        self.assertEqual(c.client.channel,1)
        self.assertEqual(c.channels[2].state,'CLEARED')
        self.assertEqual(len(c.channels[2].history.failed_clears),1)
        self.assertEqual(c.client.virtual_time,28.)

    def test_failed_entire_cover_is_unresolved(self):
        c, _ = self.make_controller([{'channel':2,'position':[100,0],'radius':1000}])
        c.channels[2].state='FOUND'
        c.execute_optical(2, {'points':np.array([[0.,0.]]),'bound_s':3.})
        self.assertEqual(c.channels[2].state,'UNRESOLVED')

    def test_expensive_replan_keeps_saved_branch(self):
        c, _ = self.make_controller([{'channel':2,'position':[100,0],'radius':1000}])
        ch=c.channels[2]; ch.state='FOUND'; ch.history.add_direction([-10,0],0.)
        saved={'kind':'optical','points':np.array([[100.,0.]]),'bound_s':30.,'certificate':{}}
        first={'kind':'measure','point':[0.,1.],'bound_s':100.,
               'branches':{i:saved for i in range(90)}}
        expensive={**saved,'bound_s':40.}
        zero=lambda points, channel: np.zeros(len(np.atleast_2d(points)))
        with patch('run.optical_catalog',return_value=[saved]), \
             patch('run.choose_action',side_effect=[first,expensive]):
            c.service(2,zero)
        self.assertEqual(ch.followups,1)
        self.assertEqual(ch.state,'CLEARED')
        self.assertTrue(any(e['kind']=='saved_policy_retained' for e in c.events))
        end=[e for e in c.events if e['kind']=='service_end'][0]
        self.assertLessEqual(end['realized_with_frozen_suffix_s'],end['initial_bound_s'])

    def test_followup_limit_is_lifetime_state(self):
        c,_=self.make_controller([{'channel':2,'position':[100,0],'radius':1000}])
        ch=c.channels[2];ch.state='FOUND';ch.followups=3
        ch.history.add_direction([-10,0],0.)
        optical={'kind':'optical','points':np.array([[100.,0.]]),'bound_s':25.,'certificate':{}}
        zero=lambda points, channel:np.zeros(len(np.atleast_2d(points)))
        with patch('run.optical_catalog',return_value=[optical]), \
             patch('run.choose_action',return_value=optical) as choose:
            c.service(2,zero)
        self.assertEqual(choose.call_args.args[4],0)
        self.assertEqual(ch.followups,3)
        self.assertEqual(c.client.measures,0)

    def test_expired_resume_adopts_confirmed_records_before_exit(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        cfg=json.loads((Path(run.__file__).parent/'config.json').read_text())
        backend=run.OfflineBackend({'seed':1,'sources':[]})
        original=run.JournalClient(backend,tmp.name,'resume-test',cfg)
        original.call('/enter');original.call('/measure',[10,0],4);original.close()
        resumed=run.JournalClient(backend,tmp.name,'resume-test',cfg,resume=True,live=True)
        self.addCleanup(resumed.close)
        resumed.call('/enter');resumed.deadline=0
        with self.assertRaises(run.BudgetStop):resumed.check_budget()
        original_measures=backend._measure
        self.assertTrue(resumed.drain_confirmed_replay_for_exit())
        self.assertEqual(backend._measure,original_measures)
        self.assertEqual(resumed.channel,4)
        np.testing.assert_array_equal(resumed.p,[10,0])
        resumed.call('/exit')
        self.assertTrue(backend._ended)

    def test_exit_never_bypasses_an_unconfirmed_journal_request(self):
        c,_=self.make_controller([])
        c.client.records.append({'path':'/measure','payload':{'request_id':'uncertain'}})
        self.assertFalse(c.client.drain_confirmed_replay_for_exit())
        self.assertTrue(c.client.pending)

    def test_non_centidegree_response_is_not_used_by_certified_bins(self):
        c,backend=self.make_controller([{'channel':2,'position':[100,0],'radius':1000}])
        exchange=backend.exchange
        def altered(path,payload):
            reply=exchange(path,payload)
            if path=='/measure':reply={**reply,'svd_deg':12.345}
            return reply
        with patch.object(backend,'exchange',side_effect=altered):
            with self.assertRaises(run.ProtocolError):c.client.call('/measure',[0,0],2)
        self.assertTrue(c.client.pending)


if __name__=='__main__': unittest.main()
