"""Independent accounting and finite-search checks for the route evaluator."""

import itertools
import unittest

import numpy as np

from routing import PlanEvaluator, optimize_tasks, _PlanCache


def catalog(*routes):
    return [{"points": np.asarray(points, dtype=float),
             "certificate": {"certified": True}} for points in routes]


class RoutingTests(unittest.TestCase):
    def test_suffix_cache_is_equal_for_all_channels_and_scan_contexts(self):
        route = np.array([[0., 0.], [5., 0.], [10., 0.]])
        catalogs = {2: catalog([[0, 0], [2, 0]]), 3: catalog([[8, 0]])}
        radio = {2: {"point": [1, 0], "branches": {
            0: catalog([[1, 0], [3, 0]], [[4, 0]]), 1: catalog([[2, 0]])}}}
        scan_sets = {0: [1, 3], 1: [1, 2], 2: [1]}
        cfg = {}
        cache = _PlanCache()
        points = [[0, 0], [13, 2], [-4, 1]]
        common = [("search", 0), ("source", 3), ("search", 2)]
        orders = [common, [("source", 2)] + common,
                  [("search", 1), ("source", 2)] + common,
                  [("source", 2), ("search", 1)] + common]
        for tasks in orders:
            cached = PlanEvaluator(tasks, catalogs, route, scan_sets, cfg, radio, cache)
            plain = PlanEvaluator(tasks, catalogs, route, scan_sets, cfg, radio)
            for channel in range(1, 21):
                np.testing.assert_array_equal(cached.value(points, channel),
                                              plain.value(points, channel))
        self.assertGreater(cache.hits, 0)
        # This identical suffix has a different UNKNOWN/ending-channel rule
        # depending on whether an earlier nonempty search has already happened.
        self.assertIn((tuple(common), False), cache.nodes)
        self.assertIn((tuple(common), True), cache.nodes)
        with self.assertRaises(ValueError):
            PlanEvaluator(common, dict(catalogs), route, scan_sets, cfg, radio, cache)

    def test_cached_and_uncached_optimization_choose_identical_plans(self):
        catalogs = {3: catalog([[18, 4]], [[15, 3], [18, 4]]),
                    4: catalog([[2, -4]])}
        radio = {3: {"point": [10, 2], "branches": {
            0: catalog([[17, 4]]), 1: catalog([[18, 3]], [[16, 3]])}}}
        args = ([0, 0], 1, [1, 2], [3, 4], catalogs,
                [[0, 0], [10, 0], [20, 0]], {1: [1, 2], 2: [1, 2]})
        cached = optimize_tasks(*args, {"task_2opt_passes": 2}, radio_catalogs=radio)
        plain = optimize_tasks(*args, {"task_2opt_passes": 2, "routing_cache": False},
                               radio_catalogs=radio)
        for key in ("tasks", "value", "insertion_value", "evaluations",
                    "two_opt_accepted", "two_opt_rounds", "two_opt_evaluations"):
            self.assertEqual(cached[key], plain[key])
        self.assertGreater(cached["suffix_cache_hits"], 0)
        self.assertGreater(cached["catalog_preparations"], 0)
        self.assertEqual(cached["radio_preparations"], 1)
        self.assertEqual(plain["suffix_cache_hits"], 0)

    def test_radio_branch_counts_entry_into_its_optical_route(self):
        radio = {2: {"point": [10, 0], "branches": {0: catalog([[60, 0]])}}}
        evaluator = PlanEvaluator([("source", 2)],
                                  {2: catalog([[1000, 0]])}, [[0, 0]], {}, {}, radio)
        # 2 s to S, 1 switch + 5 measure, 10 s to branch clear point, 5 clear.
        self.assertEqual(evaluator.value([0, 0], 1)[0], 23.0)

    def test_radio_optimizes_inside_each_bin_before_worst_bin(self):
        radio = {2: {"point": [0, 0], "branches": {
            0: catalog([[10, 0]], [[100, 0]]),
            1: catalog([[20, 0]], [[200, 0]]),
        }}}
        evaluator = PlanEvaluator([("source", 2)],
                                  {2: catalog([[1000, 0]])}, [[0, 0]], {}, {}, radio)
        # Each bin chooses its own certified policy; max(7,9) + 5 measure.
        self.assertEqual(evaluator.value([0, 0], 2)[0], 14.0)

    def test_radio_ending_channel_is_passed_to_successor(self):
        radio = {2: {"point": [0, 0], "branches": {0: catalog([[0, 0]])}}}
        evaluator = PlanEvaluator([("source", 2), ("search", 0)],
                                  {2: catalog([[1000, 0]])}, [[0, 0]], {0: [1]},
                                  {}, radio)
        # 1 initial switch + 5 measure + 5 clear + 11 scan on channel 2.
        self.assertEqual(evaluator.value([0, 0], 1)[0], 22.0)
        self.assertEqual(evaluator.value([0, 0], 2)[0], 21.0)

    def test_half_second_reversal_selects_optical_in_full_c(self):
        radio = {2: {"point": [0, 0], "branches": {0: catalog([[0, 0]])}}}
        evaluator = PlanEvaluator([("source", 2), ("search", 0)],
                                  {2: catalog([[16.25, 0]])}, [[0, 0]], {0: [1]},
                                  {}, radio)
        # Radio alone is 11 vs 11.5 for optical plus return. Its successor
        # switch adds 1, so complete C selects optical at 21.5, not radio 22.
        self.assertEqual(evaluator.value([0, 0], 1)[0], 21.5)

    def test_insertion_value_uses_radio_gain_and_can_change_order(self):
        args = ([0, 0], 1, [1, 2], [4], {4: catalog([[1000, 0]])},
                [[0, 0], [10, 0], [20, 0]], {1: [1], 2: [1]},
                {"task_2opt_passes": 0})
        radio = {4: {"point": [0, 0], "branches": {0: catalog([[0, 0]])}}}
        optical = optimize_tasks(*args)
        measured = optimize_tasks(*args, radio_catalogs=radio)
        self.assertLess(measured["value"], optical["value"])
        self.assertEqual(optical["tasks"].index(("source", 4)), 2)
        self.assertEqual(measured["tasks"].index(("source", 4)), 0)

    def test_half_second_local_ranking_reverses_after_channel_cost(self):
        evaluator = PlanEvaluator([("search", 0)], {}, [[0, 0]],
                                  {0: [1, 3]}, {})
        optical_local, radio_local = 100.0, 99.5
        self.assertLess(radio_local, optical_local)
        optical_total = optical_local + evaluator.value([0, 0], 1)[0]
        radio_total = radio_local + evaluator.value([0, 0], 2)[0]
        self.assertEqual(radio_total - optical_total, 0.5)

    def test_first_scan_finishes_at_actual_ordered_channel(self):
        evaluator = PlanEvaluator([("search", 0), ("search", 1)], {},
                                  [[0, 0], [0, 0]], {0: [1, 3], 1: [1]}, {})
        # Starting at 3 scans [3,1], so the following scan saves a switch.
        self.assertEqual(evaluator.value([0, 0], 3)[0], 31.0)
        self.assertEqual(evaluator.value([0, 0], 1)[0], 32.0)

    def test_multi_source_bound_covers_every_first_success_combination(self):
        first = np.asarray([[0, 0], [4, 0]], float)
        second = np.asarray([[-2, 0], [8, 0]], float)
        evaluator = PlanEvaluator([("source", 2), ("source", 3)],
                                  {2: catalog(first), 3: catalog(second)},
                                  [[0, 0]], {}, {})
        bound = evaluator.value([0, 0], 7)[0]
        actual = []
        for i, j in itertools.product(range(2), repeat=2):
            length = np.linalg.norm(first[0])
            length += np.linalg.norm(np.diff(first[:i + 1], axis=0), axis=1).sum()
            length += np.linalg.norm(first[i] - second[0])
            length += np.linalg.norm(np.diff(second[:j + 1], axis=0), axis=1).sum()
            actual.append(length / 5 + 3 * (i + 1) + 2 + 3 * (j + 1) + 2)
        self.assertAlmostEqual(bound, max(actual))
        for value in actual:
            self.assertLessEqual(value, bound)

    def test_zero_scan_does_not_force_a_visit(self):
        evaluator = PlanEvaluator([("search", 0), ("source", 4)],
                                  {4: catalog([[10, 0]])}, [[1000, 0]],
                                  {0: []}, {})
        self.assertEqual(evaluator.value([0, 0], 1)[0], 7.0)

    def test_free_endpoint_and_suffix_convention(self):
        evaluator = PlanEvaluator([("source", 4)], {4: catalog([[10, 0]])},
                                  [[0, 0]], {}, {})
        np.testing.assert_array_equal(evaluator.value([[0, 0], [10, 0]], 1), [7, 5])
        np.testing.assert_array_equal(evaluator.suffix(1)([[99, 0]], 20), [0])
        self.assertEqual(evaluator.value(np.empty((0, 2)), 1).shape, (0,))

    def test_later_scan_subset_and_empty_skip_are_bounded(self):
        evaluator = PlanEvaluator([("search", 0), ("search", 1), ("source", 4)],
                                  {4: catalog([[12, 0]])}, [[0, 0], [5, 0]],
                                  {0: [1], 1: [1, 2]}, {})
        suffix = evaluator.suffix(1)
        for c in range(1, 21):
            upper = suffix([0, 0], c)[0]
            # Enumerate all actual subsets; an empty scan point is skipped.
            for mask in range(4):
                subset = [k for bit, k in enumerate([1, 2]) if mask & (1 << bit)]
                if not subset:
                    actual = evaluator.suffix(2)([0, 0], c)[0]
                else:
                    rest = [k for k in subset if k != c]
                    end = rest[-1] if rest else c
                    switch = len(subset) - int(c in subset)
                    actual = (1 + 10 * len(subset) + switch
                              + evaluator.suffix(2)([5, 0], end)[0])
                self.assertLessEqual(actual, upper + 1e-12)

    def test_duplicate_tasks_and_empty_searches_are_removed(self):
        result = optimize_tasks([0, 0], 1, [1, 1, 2, 0], [4, 4],
                                {4: catalog([[15, 0]])},
                                [[0, 0], [10, 0], [20, 0]],
                                {0: [], 1: [1], 2: [1]}, {}, lambda: None)
        self.assertEqual(set(result["tasks"]),
                         {("search", 1), ("search", 2), ("source", 4)})
        self.assertEqual(len(result["tasks"]), 3)

    def test_insertion_includes_front_and_tail(self):
        for point, expected in [([0, 0], 0), ([30, 0], 2)]:
            result = optimize_tasks([0, 0], 1, [1, 2], [4],
                                    {4: catalog([point])},
                                    [[0, 0], [10, 0], [20, 0]],
                                    {1: [1], 2: [1]},
                                    {"task_2opt_passes": 0}, lambda: None)
            self.assertEqual(result["tasks"].index(("source", 4)), expected)

    def test_six_anchor_skeleton_enumerates_720_orders(self):
        route = [[0, 0]] + [[1200 * np.cos(i * np.pi / 3),
                            1200 * np.sin(i * np.pi / 3)] for i in range(6)]
        result = optimize_tasks([0, 0], 1, range(1, 7), [], {}, route,
                                {j: [1] for j in range(1, 7)},
                                {"task_2opt_passes": 0}, lambda: None)
        self.assertEqual(result["skeleton_evaluations"], 720)
        self.assertAlmostEqual(result["skeleton_distance_m"], 7200)

    def test_two_opt_is_finite_and_preserves_the_task_set(self):
        result = optimize_tasks([0, 0], 1, [1, 2], [3, 4],
                                {3: catalog([[18, 4]]), 4: catalog([[2, -4]])},
                                [[0, 0], [10, 0], [20, 0]],
                                {1: [1, 2], 2: [1, 2]},
                                {"task_2opt_passes": 2}, lambda: None)
        self.assertLessEqual(result["two_opt_rounds"], 2)
        self.assertLessEqual(result["two_opt_evaluations"], 2 * 4 * 3 // 2)
        self.assertLessEqual(result["two_opt_accepted"], 2)
        self.assertLessEqual(result["value"], result["insertion_value"])
        self.assertEqual(len(result["tasks"]), 4)

    def test_missing_optical_fallback_and_budget_interrupt_propagate(self):
        with self.assertRaises(ValueError):
            PlanEvaluator([("source", 3)], {}, [[0, 0]], {}, {})

        class BudgetExpired(Exception):
            pass

        def stop():
            raise BudgetExpired()

        with self.assertRaises(BudgetExpired):
            optimize_tasks([0, 0], 1, [], [], {}, [[0, 0]], {}, {}, stop)


if __name__ == "__main__":
    unittest.main()
