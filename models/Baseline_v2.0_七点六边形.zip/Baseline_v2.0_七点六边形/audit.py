#!/usr/bin/env python3
"""Read-only audit of completed offline v2 runs. Truth is used after execution."""
import argparse
from collections import Counter
from fractions import Fraction
import json
import math
from pathlib import Path


def audit_case(folder):
    scene=json.loads((folder/'scene.json').read_text())
    summary=json.loads((folder/'summary.json').read_text())
    decisions=json.loads((folder/'decisions.json').read_text())
    sources={s['channel']:s for s in scene['sources']}
    pending={};cleared=set(); seen=set(); position=(0.,0.); channel=1
    count=Counter(); movement=0.; clock=0.; max_clock_error=0.; checks=0; errors=[]
    def check(condition, description):
        nonlocal checks
        checks+=1
        if not condition:errors.append(description)
    for line in (folder/'actions.jsonl').read_text().splitlines():
        e=json.loads(line)
        if e['event']=='request':
            rid=e['payload']['request_id']
            check(rid not in pending,'new logical requests use distinct IDs')
            pending[rid]=e
            continue
        request=pending[e['request_id']];payload=request['payload'];path=request['path'];res=e['response']
        check(res.get('accepted') is True,'offline action accepted')
        before=clock
        if path in ('/measure','/clear'):
            p=(payload['position']['x'],payload['position']['y']);k=payload['channel']
            distance=math.dist(position,p);movement+=distance;clock+=distance/5;position=p
            source=sources.get(k)
            d=math.inf if source is None or k in cleared else math.dist(source['position'],p)
            if path=='/measure':
                key=(k,p)
                check(key not in seen,'no repeated position/channel measurement')
                seen.add(key);count['measure']+=1
                count['switch']+=int(channel!=k);clock+=5+int(channel!=k);channel=k
                outcome=res['measure_result']
                if outcome=='no_signal':check(source is None or k in cleared or d>source['radius'],'no_signal geometry')
                elif outcome=='near':check(d<=5,'near geometry')
                else:
                    check(5<d<=source['radius'],'normal reception geometry')
                    beta=math.degrees(math.atan2(source['position'][1]-p[1],source['position'][0]-p[0]))
                    error=(res['svd_deg']-beta+180)%360-180
                    check(abs(error)<=1+1e-9,'bounded bearing error')
            else:
                count['clear']+=1;success=res['clear_result']=='success';clock+=3+2*success
                check(success==(d<=20),'optical success iff within 20 metres')
                if success:
                    check(k not in cleared,'distinct success')
                    cleared.add(k);count['success']+=1
        max_clock_error=max(max_clock_error,abs(clock-res['virtual_time_s']))
        check(abs(clock-res['virtual_time_s'])<1e-6,'action-level time equation')
        check(clock>=before,'monotone virtual clock')
    states={k:'UNKNOWN' for k in range(1,21)};followups=Counter();anchors={k:set() for k in states};active=None
    origin=[];service_bounds=[];failed_optical=0
    for e in decisions:
        kind=e['kind']
        if kind=='service_start':active=e['channel']
        elif kind=='service_end':
            if e['state']=='CLEARED' and e['bound_valid']:
                check(e['realized_with_frozen_suffix_s']<=e['initial_bound_s']+1e-5,'saved C/U source budget')
                service_bounds.append(e['initial_bound_s']-e['realized_with_frozen_suffix_s'])
            active=None
        elif kind=='measure':
            k=e['channel']
            if e['role']=='anchor_scan':
                check(states[k]=='UNKNOWN','search scans only never-found channels')
                check(e['anchor'] not in anchors[k],'anchor/channel scanned at most once')
                anchors[k].add(e['anchor'])
                if e['anchor']==0:origin.append(k)
            else:
                check(active==k,'dedicated point measures only active target')
                followups[k]+=1
                check(followups[k]<=3,'lifetime followup cap is three')
            if e['result'] in ('direction','near'):states[k]='FOUND'
        elif kind=='clear':
            if e['success']:states[e['channel']]='CLEARED'
            else:failed_optical+=1
            cert=e.get('certificate')
            if cert and 'max_cell_radius_sq' in cert:
                check(Fraction(cert['max_cell_radius_sq'])<=Fraction('19.9')**2,'optical coverage command radius')
        elif kind=='absent_certified':
            check(anchors[e['channel']]==set(range(7)),'absence requires all seven channel scans')
            check(states[e['channel']]=='UNKNOWN','absence never overwrites known source')
        elif kind=='global_plan':
            tasks=[tuple(t) for t in e['tasks']]
            check(len(tasks)==len(set(tasks)),'no duplicate tasks')
            check(e['two_opt_rounds']<=2,'finite task 2-opt rounds')
            check(e['value']<=e['insertion_value']+1e-7,'2-opt decreases same planning bound')
    check(origin==list(range(1,21)),'origin 1-20 full batch')
    check(cleared==set(sources),'all synthetic sources cleared')
    check(summary['completion']=='completed','controller reports completion')
    check(not summary['unresolved_channels'],'no unresolved channels')
    total=movement/5+5*count['measure']+count['switch']+3*count['clear']+2*count['success']
    check(abs(total-summary['virtual_time_s'])<1e-6,'whole-task time equation')
    check(count['measure']<=140+3*len(sources),'finite measurement bound')
    return dict(case=folder.name,checks=checks,errors=errors,sources=len(sources),cleared=len(cleared),
                virtual_time_s=clock,movement_m=movement,measures=count['measure'],switches=count['switch'],
                clear_attempts=count['clear'],failed_optical_attempts=failed_optical,
                followups=sum(followups.values()),max_followups=max(followups.values(),default=0),
                checked_service_budgets=len(service_bounds),max_clock_error_s=max_clock_error,
                wall_elapsed_s=summary.get('wall_elapsed_s'))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    args=parser.parse_args()
    cases=[args.directory] if (args.directory/'scene.json').exists() else sorted(p.parent for p in args.directory.glob('*/scene.json'))
    results=[audit_case(p) for p in cases]
    report=dict(cases=len(results),checks=sum(r['checks'] for r in results),
                errors=sum(len(r['errors']) for r in results),
                sources=sum(r['sources'] for r in results),cleared=sum(r['cleared'] for r in results),
                scope='post-run synthetic-scene audit; not official simulator validation',results=results)
    (args.directory/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='results'},ensure_ascii=False))
    raise SystemExit(1 if report['errors'] else 0)


if __name__=='__main__':main()
