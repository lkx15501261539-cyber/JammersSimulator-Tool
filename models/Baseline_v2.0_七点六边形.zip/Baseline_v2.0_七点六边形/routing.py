"""Certified costs for a finite list of currently known Q3 tasks.

Sources compare executable optical catalogues with optional one-measurement,
certified-bin optical policies.  Every possible first-success position is passed
to the successor value; no predicted source endpoint is used.  Newly discovered
sources are NOT included in this value: discovery
changes the task list and triggers a new plan.  A lower value means a lower
certified planning bound, not a guaranteed reduction of actual mission time.
"""

from __future__ import annotations

from itertools import permutations
from typing import Callable

import numpy as np


CHANNELS = 20
SPEED = 5.0


def _points(points):
    points = np.asarray(points, dtype=float)
    if points.size == 0:
        return np.empty((0, 2), dtype=float)
    if points.ndim == 1:
        points = points.reshape(1, 2)
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError("Positions must have shape (2,) or (N, 2).")
    if not np.all(np.isfinite(points)):
        raise ValueError("Positions must be finite.")
    return points


def _tasks(tasks):
    result, seen = [], set()
    for kind, identifier in tasks:
        task = (str(kind), int(identifier))
        if task[0] not in ("search", "source"):
            raise ValueError(f"Unknown task kind: {task[0]}")
        if task[0] == "source" and not 1 <= task[1] <= CHANNELS:
            raise ValueError("Source channels must be between 1 and 20.")
        if task not in seen:
            seen.add(task)
            result.append(task)
    return result


def _scan_set(scan_sets, index):
    values = sorted(set(int(k) for k in scan_sets.get(index, [])))
    if any(k < 1 or k > CHANNELS for k in values):
        raise ValueError("Scan channels must be between 1 and 20.")
    return values


class _PlanCache:
    """One optimization's immutable catalogues and context-sensitive suffixes."""

    def __init__(self):
        self.scope = None
        self.nodes = {}
        self.catalogues = {}
        self.radios = {}
        self.hits = 0
        self.misses = 0

    def bind(self, *scope):
        if self.scope is None:
            self.scope = scope
        elif any(old is not new for old, new in zip(self.scope, scope)):
            raise ValueError("A planning cache cannot cross catalogue/configuration snapshots.")


def _prepare_catalogue(catalogue, cache=None):
    key = id(catalogue)
    if cache is not None and key in cache.catalogues:
        return cache.catalogues[key]
    if not catalogue:
        raise ValueError("An optical catalogue cannot be empty.")
    routes = [_points(item["points"]) for item in catalogue]
    if any(len(points) == 0 for points in routes):
        raise ValueError("An optical route cannot be empty.")
    counts = [len(points) for points in routes]
    local = []
    for points in routes:
        prefix = np.r_[0.0, np.cumsum(
            np.linalg.norm(np.diff(points, axis=0), axis=1)
        )]
        local.append(prefix / SPEED + 3 * np.arange(1, len(points) + 1) + 2)
    prepared = {
        "owner": catalogue,
        "points": np.concatenate(routes),
        "starts": np.asarray([points[0] for points in routes]),
        "offsets": np.r_[0, np.cumsum(counts)[:-1]],
        "local": np.concatenate(local),
    }
    if cache is not None:
        cache.catalogues[key] = prepared
    return prepared


def _prepare_radio(entry, cache=None):
    key = id(entry)
    if cache is not None and key in cache.radios:
        return cache.radios[key]
    start = _points(entry["point"])
    if len(start) != 1:
        raise ValueError("A radio entry must contain one measurement point.")
    start = start[0]
    bins = [_prepare_catalogue(catalogue, cache)
            for catalogue in entry["branches"].values()]
    prepared = {"owner": entry, "start": start, "bins": len(bins)}
    if bins:
        point_offset = 0
        route_offsets = []
        for branch in bins:
            route_offsets.extend(branch["offsets"] + point_offset)
            point_offset += len(branch["points"])
        starts = np.concatenate([branch["starts"] for branch in bins])
        prepared.update(
            points=np.concatenate([branch["points"] for branch in bins]),
            local=np.concatenate([branch["local"] for branch in bins]),
            route_offsets=np.asarray(route_offsets, dtype=int),
            bin_offsets=np.r_[0, np.cumsum([len(b["starts"]) for b in bins])[:-1]],
            entry_distance=np.linalg.norm(starts - start, axis=1) / SPEED,
        )
    if cache is not None:
        cache.radios[key] = prepared
    return prepared


class PlanEvaluator:
    """Backward dynamic program for ``('search', j) / ('source', k)`` tasks.

    ``suffix(i)(points, channel)`` evaluates tasks[i:], so the terminal supplied
    when serving tasks[0] is suffix(1).  Results always have shape (N,).
    Catalogues are assumed to have already been geometrically certified by cu.
    Each member supplies a nonempty ``points`` array, in its executable order.
    Optional ``radio_catalogs[k]`` supplies a measurement ``point`` and a mapping
    ``branches[bin]`` of certified posterior optical catalogues. The caller only
    supplies it while source k has an additional measurement remaining.
    """

    def __init__(self, tasks, catalogs, route, scan_sets, cfg, radio_catalogs=None,
                 _cache=None):
        if _cache is not None:
            _cache.bind(catalogs, route, scan_sets, cfg, radio_catalogs)
        self._cache = _cache
        self.tasks = _tasks(tasks)
        self.catalogs = catalogs
        self.route = _points(route)
        self.scan_sets = scan_sets
        self.cfg = cfg
        self.radio_catalogs = radio_catalogs or {}
        self._nodes = [None] * (len(self.tasks) + 1)
        seen_search = False
        search_before = []
        first_search = None
        for index, (kind, anchor) in enumerate(self.tasks):
            search_before.append(seen_search)
            if kind == "search" and _scan_set(scan_sets, anchor):
                if not seen_search:
                    first_search = index
                seen_search = True
        for index in range(len(self.tasks) - 1, -1, -1):
            key = (tuple(self.tasks[index:]), search_before[index])
            if _cache is not None and key in _cache.nodes:
                self._nodes[index] = _cache.nodes[key]
                _cache.hits += 1
                continue
            if _cache is not None:
                _cache.misses += 1
            kind, identifier = self.tasks[index]
            if kind == "source":
                self._build_source(index, identifier)
            else:
                if not 0 <= identifier < len(self.route):
                    raise ValueError("Search index is outside the route.")
                self._build_search(index, identifier, index == first_search)
            if _cache is not None:
                _cache.nodes[key] = self._nodes[index]

    def _all_channels(self, index, points):
        points = _points(points)
        node = self._nodes[index]
        if node is None:
            return np.zeros((len(points), CHANNELS), dtype=float)
        kind = node["kind"]
        if kind == "skip":
            return self._all_channels(index + 1, points)
        if kind == "search":
            distance = np.linalg.norm(points - node["point"], axis=1)
            return distance[:, None] / SPEED + node["cost"][None, :]
        distance = np.linalg.norm(
            points[:, None, :] - node["starts"][None, :, :], axis=2
        ) / SPEED
        return np.min(distance[:, :, None] + node["h"][None, :, :], axis=1)

    def _channel(self, index, points, channel):
        """Evaluate a fixed ending channel without expanding the other 19."""
        points = _points(points)
        node = self._nodes[index]
        if node is None:
            return np.zeros(len(points), dtype=float)
        if node["kind"] == "skip":
            return self._channel(index + 1, points, channel)
        if node["kind"] == "search":
            return (np.linalg.norm(points - node["point"], axis=1) / SPEED
                    + node["cost"][channel - 1])
        distance = np.linalg.norm(
            points[:, None, :] - node["starts"][None, :, :], axis=2
        ) / SPEED
        return np.min(distance + node["h"][None, :, channel - 1], axis=1)

    def _build_source(self, index, channel):
        catalogue = self.catalogs.get(channel, [])
        if not catalogue:
            raise ValueError(f"Source {channel} has no certified optical route.")
        prepared = _prepare_catalogue(catalogue, self._cache)
        successor = self._all_channels(index + 1, prepared["points"])
        h = list(np.maximum.reduceat(
            successor + prepared["local"][:, None], prepared["offsets"], axis=0
        ))
        starts = list(prepared["starts"])
        radio = self.radio_catalogs.get(channel)
        if radio is not None:
            entries = radio if isinstance(radio, (list, tuple)) else [radio]
            for entry in entries:
                prepared_radio = _prepare_radio(entry, self._cache)
                start = prepared_radio["start"]
                worst = self._radio_successor(index, channel, prepared_radio)
                h.append(5.0 + (np.arange(1, CHANNELS + 1) != channel) + worst)
                starts.append(start)
        self._nodes[index] = {
            "kind": "source", "starts": np.asarray(starts), "h": np.asarray(h),
        }

    def _radio_successor(self, index, channel, prepared):
        # near clears at S and retains the measurement channel k.
        start = prepared["start"]
        worst = 5.0 + float(self._channel(index + 1, start, channel)[0])
        if not prepared["bins"]:
            return worst
        # The bin and geometric certificates are supplied by cu. Their points
        # are independent of incoming position/channel and can be batch scored.
        successor = self._channel(index + 1, prepared["points"], channel)
        route_values = (np.maximum.reduceat(successor + prepared["local"],
                                           prepared["route_offsets"])
                        + prepared["entry_distance"])
        bin_values = np.minimum.reduceat(route_values, prepared["bin_offsets"])
        return max(worst, float(np.max(bin_values)))

    def _build_search(self, index, anchor, exact):
        channels = _scan_set(self.scan_sets, anchor)
        if not channels:
            self._nodes[index] = {"kind": "skip"}
            return
        point = self.route[anchor]
        following = self._all_channels(index + 1, point)[0]
        q = len(channels)
        cost = np.empty(CHANNELS)
        for channel in range(1, CHANNELS + 1):
            switches = q - int(channel in channels)
            # q measurements plus at most q immediate near-clear successes.
            scan_bound = 5 * q + switches + 5 * q
            if exact:
                remaining = [k for k in channels if k != channel]
                end_channel = remaining[-1] if remaining else channel
                after = following[end_channel - 1]
            else:
                # Prior searches can discover a subset of these channels.
                # The empty subset retains c; any nonempty subset ends in K.
                possible = set(channels) | {channel}
                after = max(following[k - 1] for k in possible)
            cost[channel - 1] = scan_bound + after
        self._nodes[index] = {"kind": "search", "point": point, "cost": cost}

    def value(self, points, c):
        return self.suffix(0)(points, c)

    def suffix(self, index) -> Callable:
        index = int(index)
        if not 0 <= index <= len(self.tasks):
            raise IndexError("Suffix index must be between 0 and len(tasks).")

        def terminal(points, c):
            channel = int(c)
            if not 1 <= channel <= CHANNELS:
                raise ValueError("Current channel must be between 1 and 20.")
            return self._channel(index, points, channel)

        return terminal


def optimize_tasks(p, c, pending_indices, found_channels, catalogs, route,
                   scan_sets, cfg, check_budget=None, radio_catalogs=None):
    """Exact search skeleton, greedy insertion, then bounded full-value 2-opt.

    Intermediate insertion scores cover the tasks inserted so far; the final
    score covers every currently listed FOUND source and retained search task.
    Each eligible source compares immediate optical cleanup with one additional
    measurement and a certified optical policy for every response bin. This
    one-step C is used for every candidate insertion and 2-opt comparison. The
    controller may roll it forward, preserving its accepted branch budget.
    Budget exceptions propagate, allowing the caller to keep its saved plan.
    """
    p = _points(p)
    if len(p) != 1:
        raise ValueError("The current position must be a single point.")
    route = _points(route)
    pending = sorted(set(int(j) for j in pending_indices))
    if any(j < 0 or j >= len(route) for j in pending):
        raise ValueError("Search index is outside the route.")
    pending = [j for j in pending if _scan_set(scan_sets, j)]
    if len(pending) > 6:
        raise ValueError("After the origin scan, at most six anchors remain.")
    remaining = sorted(set(int(k) for k in found_channels))
    if any(k < 1 or k > CHANNELS for k in remaining):
        raise ValueError("Source channels must be between 1 and 20.")
    passes = int(cfg.get("task_2opt_passes", 2))
    if not 0 <= passes <= 3:
        raise ValueError("task_2opt_passes must be an integer from 0 to 3.")
    tolerance = float(cfg.get("routing_improvement_tol", 1e-9))
    if not np.isfinite(tolerance) or tolerance < 0:
        raise ValueError("routing_improvement_tol must be finite and nonnegative.")

    def budget():
        if check_budget is not None:
            check_budget()

    skeleton_evaluations, best_geometry, order = 0, None, ()
    for candidate in permutations(pending):
        budget()
        skeleton_evaluations += 1
        points = np.vstack([p, route[list(candidate)]])
        distance = float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())
        key = (distance, candidate)
        if best_geometry is None or key < best_geometry:
            best_geometry, order = key, candidate
    tasks = [("search", j) for j in order]
    cache = {}
    planning_cache = _PlanCache() if cfg.get("routing_cache", True) else None

    def score(candidate):
        budget()
        key = tuple(candidate)
        if key not in cache:
            evaluator = PlanEvaluator(candidate, catalogs, route, scan_sets, cfg,
                                      radio_catalogs=radio_catalogs, _cache=planning_cache)
            cache[key] = float(evaluator.value(p, c)[0])
        return cache[key]

    current_value = score(tasks)
    while remaining:
        choice = None
        for channel in remaining:
            for position in range(len(tasks) + 1):
                candidate = tasks[:position] + [("source", channel)] + tasks[position:]
                value = score(candidate)
                key = (value - current_value, channel, position)
                if choice is None or key < choice[0]:
                    choice = (key, candidate, value, channel)
        _, tasks, current_value, channel = choice
        remaining.remove(channel)

    insertion_value = current_value
    two_opt_evaluations, accepted, rounds = 0, 0, 0
    if len(tasks) >= 2:
        for _ in range(passes):
            rounds += 1
            best_tasks, best_value = tasks, current_value
            for left in range(len(tasks) - 1):
                for right in range(left + 1, len(tasks)):
                    candidate = (tasks[:left] + list(reversed(tasks[left:right + 1]))
                                 + tasks[right + 1:])
                    value = score(candidate)
                    two_opt_evaluations += 1
                    if value < best_value - tolerance:
                        best_tasks, best_value = candidate, value
            if best_tasks is tasks:
                break
            tasks, current_value = best_tasks, best_value
            accepted += 1

    return {
        "tasks": tasks, "value": current_value, "evaluations": len(cache),
        "skeleton_evaluations": skeleton_evaluations,
        "skeleton_distance_m": best_geometry[0],
        "insertion_value": insertion_value, "two_opt_rounds": rounds,
        "two_opt_evaluations": two_opt_evaluations,
        "two_opt_accepted": accepted,
        "suffix_cache_hits": planning_cache.hits if planning_cache else 0,
        "suffix_cache_misses": planning_cache.misses if planning_cache else 0,
        "catalog_preparations": len(planning_cache.catalogues) if planning_cache else 0,
        "radio_preparations": len(planning_cache.radios) if planning_cache else 0,
    }
