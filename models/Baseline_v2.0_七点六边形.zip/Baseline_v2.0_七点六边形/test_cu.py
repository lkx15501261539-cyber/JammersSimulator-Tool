"""Independent boundary/cost checks for the C/U implementation."""
import math
import unittest
from fractions import Fraction as F
from unittest.mock import patch

import numpy as np

import cu
from solver import History, PlanningError, certify_reception, exact_halfplanes


class CUTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cfg = {'optical_radius_m': 19.9, 'bearing_bin_deg': 4.,
                   'bearing_resolution_deg': .01}

    def test_continuous_cell_certificate_includes_actual_mm_rounding(self):
        polygon = [(F(1, 10000), F(-13)), (F(10001, 100), F(-13)),
                   (F(10001, 100), F(14)), (F(1, 10000), F(14))]
        catalog = cu.catalog_from_polygon(polygon, self.cfg)
        item = next(v for v in catalog
                    if v['certificate']['method'] == 'rational_rectangle_cells')
        cert = item['certificate']
        a, b = map(F, cert['orientation'])
        self.assertEqual(a*a+b*b, 1)
        ul, uh, vl, vh = map(F, cert['local_bounds'])
        cols, rows = cert['columns'], cert['rows']
        points = [tuple(F(int(round(x*1000)), 1000) for x in p)
                  for p in item['points']]
        # At every partition corner at least one actually transmitted disk
        # covers it. Convex disks then cover their entire rectangle cells.
        for row in range(rows+1):
            for col in range(cols+1):
                u = ul+(uh-ul)*col/cols
                v = vl+(vh-vl)*row/rows
                point = (a*u-b*v, b*u+a*v)
                self.assertLessEqual(min(cu._d2(point, p) for p in points), F(199, 10)**2)
        self.assertLessEqual(F(cert['max_cell_radius_sq']), F(199, 10)**2)

    def test_circle_outer_planes_are_outward_for_all_angles(self):
        for a, b, norm in cu._circle_normals():
            self.assertGreaterEqual(norm*norm, a*a+b*b)

    def test_general_terminal_requires_maximum_over_early_success(self):
        item = {'points': np.array([[0., 0.], [1., 0.]]),
                'certificate': {'certified': True}}
        def terminal(points, channel):
            return np.array([1000. if p[0] == 0 else 0. for p in points])
        plan = cu.optical_value([item], [0, 0], 3, terminal)
        self.assertGreaterEqual(plan['bound_s'], 1005.)
        self.assertLess(plan['bound_s'], 1005.+1e-8)
        self.assertGreater(plan['bound_s'], plan['prefix_bounds_s'][-1]+900.)

    def test_optical_preserves_the_entry_channel_in_terminal(self):
        seen = []
        def terminal(points, channel):
            seen.append(channel)
            return np.zeros(len(points))
        cu.optical_value([{'points': np.zeros((1, 2)), 'certificate': {}}],
                         [0, 0], 17, terminal)
        self.assertEqual(seen, [17])

    def test_optical_2opt_keeps_endpoints_coverage_and_original_policy(self):
        points = np.array([[0., 0.], [1., 1.], [0., 1.], [1., 0.]])
        original = {'points': points, 'certificate': {'certified': True}}
        candidates = cu._add_2opt([original], {'optical_2opt_passes': 1}, lambda: None)
        self.assertIs(candidates[0], original)
        self.assertEqual(len(candidates), 2)
        refined = candidates[1]['points']
        np.testing.assert_equal(refined[[0, -1]], points[[0, -1]])
        self.assertEqual(set(map(tuple, refined)), set(map(tuple, points)))
        self.assertLess(np.linalg.norm(np.diff(refined, axis=0), axis=1).sum(),
                        np.linalg.norm(np.diff(points, axis=0), axis=1).sum())

    def test_radio_catalog_cache_is_independent_of_terminal_and_entry(self):
        history = History()
        history.add_direction([0, 0], 0.)
        candidate = {'point': [750., 500.], 'reception_certificate': {'certified': True}}
        with patch.object(cu, 'plan_next', return_value=candidate) as planner:
            a = cu.radio_catalog(history, self.cfg)
            b = cu.radio_catalog(history, self.cfg)
            self.assertIs(a, b)
            self.assertEqual(planner.call_count, 1)
            history.failed_clears.append([100., 0.])
            c = cu.radio_catalog(history, self.cfg)
            self.assertIsNot(a, c)
            self.assertEqual(planner.call_count, 2)

    def test_single_disk_uses_radius_not_only_diameter(self):
        side = 39.
        triangle = [[0, 0], [side, 0], [side/2, side*math.sqrt(3)/2]]
        catalog = cu.catalog_from_polygon(triangle, self.cfg)
        self.assertFalse(any(v['certificate']['method'] == 'single_disk' for v in catalog))

    def test_single_point_and_collinear_sets(self):
        for polygon in ([[3.001, 4.001]], [[0, 0], [30, 0]]):
            catalog = cu.catalog_from_polygon(polygon, self.cfg)
            self.assertTrue(any(v['certificate']['method'] == 'single_disk' for v in catalog))

    def test_H0_104_is_independently_certified(self):
        history = History()
        history.add_direction([1200, 0], 163.23)
        cu.optical_catalog(history, self.cfg)
        fallback = [v for v in history._cu_initial_fallback
                    if v['certificate'].get('candidate') == 'first_history_H0_104']
        self.assertTrue(fallback)
        self.assertTrue(all(len(v['points']) == 104 for v in fallback))
        self.assertTrue(all(F(v['certificate']['max_cell_radius_sq']) <= F(199, 10)**2
                            for v in fallback))

    def test_pruning_limits_keep_entire_certified_policies(self):
        polygon = [[0., 0.], [100., 70.], [90., 85.], [-10., 15.]]
        wide_cfg = dict(self.cfg, optical_catalog_limit=100,
                        optical_point_count_factor=10.)
        original = cu.catalog_from_polygon(polygon, wide_cfg)
        constrained = dict(self.cfg, optical_catalog_limit=3,
                           optical_point_count_factor=1.5)
        kept = cu._prune_catalog(original+original, constrained)
        self.assertGreaterEqual(len(kept), 1)
        self.assertLessEqual(len(kept), 3)
        shortest = min(len(item['points']) for item in original)
        for item in kept:
            self.assertTrue(any(item is old for old in original))
            self.assertLessEqual(len(item['points']), shortest*1.5+2)
            self.assertTrue(item['certificate']['certified'])
            self.assertLessEqual(F(item['certificate']['max_cell_radius_sq']), F(199, 10)**2)
        # Pruning a single reliable cover cannot produce an empty catalog.
        self.assertIs(cu._prune_catalog([original[0]], constrained)[0], original[0])
        again = cu._prune_catalog(list(reversed(original)), constrained)
        self.assertEqual([tuple(map(tuple, item['points'])) for item in kept],
                         [tuple(map(tuple, item['points'])) for item in again])

    def test_catalog_caps_apply_to_history_and_each_response(self):
        history = History()
        history.add_direction([0, 0], 45.)
        cfg = dict(self.cfg, optical_catalog_limit=8, optical_point_count_factor=1.5)
        catalog = cu.optical_catalog(history, cfg)
        self.assertLessEqual(len(catalog), 8)
        self.assertTrue(history._cu_initial_fallback)
        count = min(len(item['points']) for item in catalog)
        self.assertTrue(all(len(item['points']) <= count*1.5+2 for item in catalog))
        candidate = {'point': [750., 500.], 'reception_certificate': {'certified': True}}
        with patch.object(cu, 'plan_next', return_value=candidate):
            radio = cu.radio_catalog(history, cfg)
        self.assertTrue(radio['branches'])
        for branch in radio['branches'].values():
            self.assertGreaterEqual(len(branch), 1)
            self.assertLessEqual(len(branch), 8)

    def test_history_cache_tracks_negatives_and_optical_failures(self):
        history = History()
        history.add_direction([0, 0], 0.)
        original = cu.optical_catalog(history, self.cfg)
        history.negatives.append([-1500., 0.])
        second = cu.optical_catalog(history, self.cfg)
        self.assertIsNot(original, second)
        history.failed_clears.append([100., 0.])
        third = cu.optical_catalog(history, self.cfg)
        self.assertIsNot(second, third)
        self.assertEqual(history.observations, [(0., 0., 0.)])

    def test_all_centidegree_responses_fit_the_90_bins(self):
        cert = cu._certify_direction_bins(4., .01)
        self.assertEqual(cert['responses_checked'], 36000)
        self.assertEqual(cert['bins'], 90)
        self.assertEqual(cu.bearing_bin_index(359.99), 89)
        self.assertEqual(cu.bearing_bin_index(360.), 0)
        self.assertEqual(cu.bearing_bin_index(-.01), 89)
        poly = [(F(-100), F(-100)), (F(100), F(-100)),
                (F(100), F(100)), (F(-100), F(100))]
        box = cu._bin_outer(poly, [0, 0], 0, 4.)
        self.assertTrue(box)
        self.assertTrue(any(y < 0 and x > 0 for x, y in box))

    def test_zero_budget_uses_no_Q2_call(self):
        history = History()
        history.add_direction([0, 0], 0.)
        with patch.object(cu, 'plan_next', side_effect=AssertionError('Q2 should not run')):
            result = cu.choose_action(history, [0, 0], 1, 2, 0, self.cfg)
        self.assertEqual(result['kind'], 'optical')

    def test_measurement_retains_all_response_policies_and_near(self):
        history = History()
        history.add_direction([0, 0], 0.)
        candidate = [750., 500.]
        cert = certify_reception(history, candidate)
        self.assertTrue(cert['certified'])
        def proposed(actual_history, cfg, budget):
            self.assertIs(actual_history, history)
            return {'point': candidate, 'reception_certificate': cert}
        with patch.object(cu, 'plan_next', side_effect=proposed):
            result = cu.choose_action(history, [0, 0], 3, 7, 3, self.cfg)
        self.assertEqual(result['kind'], 'measure')
        self.assertGreaterEqual(result['near_cost'], 5.)
        self.assertTrue(result['branches'])
        self.assertGreaterEqual(result['bound_s'], result['measurement_cost_s']+
                                max(v['bound_s'] for v in result['branches'].values()))
        for source in ([100., 0.], [800., 0.], [1450., 0.]):
            bearing = round(math.degrees(math.atan2(source[1]-500., source[0]-750.)) % 360, 2)
            index = cu.bearing_bin_index(bearing)
            branch = result['branches'][index]
            self.assertLessEqual(np.linalg.norm(branch['points']-source, axis=1).min(), 20.)
            self.assertEqual(branch['channel'], 7)

    def test_unproved_measurement_candidate_cannot_escape_optical_fallback(self):
        history = History()
        history.add_direction([0, 0], 0.)
        with patch.object(cu, 'plan_next', return_value={'point': [500, 500]}):
            result = cu.choose_action(history, [0, 0], 1, 2, 3, self.cfg)
        self.assertEqual(result['kind'], 'optical')

    def test_complete_radius_history_is_not_replaced_by_position_samples(self):
        history = History()
        history.add_direction([0, 0], 0.)
        # The earlier negative excludes X=(100,0): the same fixed R must be
        # at least 1000 but this negative point is only 600 m from X.
        self.assertTrue(history.compatible([100., 0.]))
        history.negatives.append([-500., 0.])
        self.assertFalse(history.compatible([100., 0.]))
        self.assertTrue(history.compatible([1000., 0.]))
        self.assertTrue(certify_reception(history, [750., 500.])['certified'])

    def test_budget_interrupt_is_not_suppressed(self):
        history = History()
        history.add_direction([0, 0], 0.)
        class Stop(RuntimeError):
            pass
        def stop():
            raise Stop()
        with self.assertRaises(Stop):
            cu.choose_action(history, [0, 0], 1, 2, 3, self.cfg, check_budget=stop)


if __name__ == '__main__':
    unittest.main()
