#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Baseline v1.0: fixed coverage skeleton + single-target roadside service.
No opportunity scans; no reordered skeleton; after each service go to next anchor.
Defaults to OFFLINE. The live mode never starts an official GUI test for you.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import random
import sys
import time
import uuid
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from dataclasses import dataclass, field
import numpy as np
from solver import (History, PlanningError, clearance, plan_next, point_key, snap,
                    segment_distance, exact_route_certificate, warmup)

HERE=Path(__file__).resolve().parent


class ProtocolError(RuntimeError):pass
class UncertainAction(ProtocolError):pass
class BudgetStop(RuntimeError):pass


def jsonable(x):
    if isinstance(x,np.ndarray):return jsonable(x.tolist())
    if isinstance(x,np.integer):return int(x)
    if isinstance(x,(float,np.floating)) and not math.isfinite(float(x)):return str(x)
    if isinstance(x,dict):return {str(k):jsonable(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [jsonable(y) for y in x]
    return x


def save_json(path,x):
    path=Path(path); tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(jsonable(x),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    tmp.replace(path)


class LiveBackend:
    def __init__(self,url,timeout=5.,retries=3):
        from urllib.parse import urlparse
        z=urlparse(url)
        if z.scheme!='http' or z.hostname not in ('127.0.0.1','localhost','::1') or z.path not in ('','/'):
            raise ValueError('Use the official LOCAL loopback HTTP address, e.g. http://127.0.0.1:2026')
        self.url=url.rstrip('/');self.timeout=timeout;self.retries=retries

    def exchange(self,path,payload):
        # This byte string AND request_id remain exactly the same across retries.
        data=json.dumps(payload,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf-8')
        last=None
        for attempt in range(self.retries+1):
            req=Request(self.url+path,data=data,headers={'Content-Type':'application/json; charset=utf-8'},method='POST')
            try:
                with urlopen(req,timeout=self.timeout) as res:
                    status=res.status;body=res.read()
                if status!=200:raise ProtocolError(f'HTTP {status}')
                reply=json.loads(body.decode('utf-8'))
                if not isinstance(reply,dict):raise ValueError('non-object reply')
                return reply
            except HTTPError as exc:
                if exc.code not in (429,500,502,503,504):
                    raise ProtocolError(f'HTTP {exc.code}; request stopped; inspect journal') from exc
                last=exc
            except (URLError,TimeoutError,ConnectionError,OSError,ValueError) as exc:last=exc
            if attempt<self.retries:time.sleep(min(.25*2**attempt,2.))
        raise UncertainAction(f'No complete response after same-ID retries: {last}. '
                              'Do NOT send a new action; resume with this journal.')


class OfflineBackend:
    """Hidden-truth test environment. Controller consumes only exchange() responses.
    Synthetic, NOT the official simulator. No network or actual laser is involved.
    """
    def __init__(self,scene):
        self._sources={int(x['channel']):dict(x) for x in scene['sources']}
        self._cleared=set();self._noise_seed=scene['seed'];self._cache={}
        self._p=np.zeros(2);self._channel=1;self._t=0.;self._entered=False;self._ended=False
        self._measure=0;self._switch=0;self._clear=0;self._move=0.

    def _response(self,**kw):
        return dict(accepted=True,real_timestamp_ms=int(time.time()*1000),virtual_time_s=self._t,**kw)

    def exchange(self,path,payload):
        signature=json.dumps([path,payload],sort_keys=True,ensure_ascii=False)
        rid=payload['request_id']
        if rid in self._cache:
            old,reply=self._cache[rid]
            if old!=signature:raise ProtocolError('mock 409: same request_id changed')
            return dict(reply)
        if path not in ('/enter','/measure','/clear','/exit'):raise ProtocolError('mock 404')
        allowed={'arena_id','robot_id','request_id'} | ({'position','channel'} if path in ('/measure','/clear') else set())
        if set(payload)!=allowed or payload['arena_id']!='default':
            return dict(accepted=False,real_timestamp_ms=0,virtual_time_s=0)
        if path=='/enter':
            if self._entered:return dict(accepted=False,real_timestamp_ms=0,virtual_time_s=0)
            self._entered=True
            reply=self._response(max_virtual_duration_s=360000,max_real_duration_s=1200,remaining_real_duration_s=1200)
        elif not self._entered or self._ended:
            return dict(accepted=False,real_timestamp_ms=0,virtual_time_s=0)
        elif path=='/exit':self._ended=True;reply=self._response(exit_reason='user_exit')
        else:
            k=payload['channel'];p=np.array([payload['position']['x'],payload['position']['y']],dtype=float)
            if type(k)!=int or not 1<=k<=20 or not np.isfinite(p).all() or max(abs(p))>2e6:raise ProtocolError('mock 400')
            if set(payload['position'])!={'x','y'}:return dict(accepted=False,real_timestamp_ms=0,virtual_time_s=0)
            move=float(np.linalg.norm(p-self._p));self._move+=move;self._t+=move/5.;self._p=p
            source=self._sources.get(k)
            present=source is not None and k not in self._cleared
            d=math.inf if not present else float(np.linalg.norm(p-np.array(source['position'])))
            if path=='/measure':
                sw=int(k!=self._channel);self._channel=k;self._measure+=1;self._switch+=sw;self._t+=5+sw
                if not present or d>source['radius']:reply=self._response(measure_result='no_signal')
                elif d<=5:reply=self._response(measure_result='near')
                else:
                    s=np.array(source['position']);beta=math.degrees(math.atan2(s[1]-p[1],s[0]-p[0]))
                    # Fixed bounded spatial field. 0.994 amplitude leaves room for 0.01° rounding.
                    z=.00637*p[0]+.00413*p[1]+1.713*k+.017*self._noise_seed
                    error=.994*math.sin(z)
                    theta=round((beta+error)%360.,2)%360.
                    reply=self._response(measure_result='direction',svd_deg=theta)
            else:
                self._clear+=1;success=present and d<=20.;self._t+=5 if success else 3
                if success:self._cleared.add(k)
                reply=self._response(clear_result='success' if success else 'no_target_in_range')
        self._cache[rid]=(signature,dict(reply));return reply

    def evaluation(self):
        # Called by the experiment harness only AFTER the controller has terminated.
        return {'actual_source_count':len(self._sources),'actual_cleared_count':len(self._cleared),
            'clearance_ratio':len(self._cleared)/len(self._sources) if self._sources else 1.,
            'actual_remaining_channels':sorted(set(self._sources)-self._cleared),
            'virtual_time_s':self._t,'movement_m':self._move,'measures':self._measure,
            'switches':self._switch,'clear_attempts':self._clear}


class JournalClient:
    """Write-ahead, same-ID retries and deterministic accepted-response replay.
    --resume replays this session, never /enter-s a new test. Keep code/config frozen.
    """
    def __init__(self,backend,out,robot_id,settings,resume=False,live=False):
        self.backend=backend;self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True)
        self.live=live;self.robot_id=robot_id;self.p=np.zeros(2);self.channel=1;self.virtual_time=0.
        self.measures=self.switches=self.clear_attempts=self.successes=0;self.movement=0.
        self.deadline=math.inf;self.max_virtual=360000.;self.cursor=0;self.records=[];self.pending=False
        self.settings=settings;digest=hashlib.sha256(json.dumps(settings,sort_keys=True).encode()).hexdigest()
        code_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.glob('*.py')}
        manifest=self.out/'session.json'
        if manifest.exists():
            if not resume:raise ValueError('Output has an existing session; use a new directory or --resume')
            meta=json.loads(manifest.read_text(encoding='utf-8'))
            if meta['settings_sha256']!=digest or meta['robot_id']!=robot_id:raise ValueError('Resume config/robot_id mismatch')
            if meta.get('code_sha256')!=code_hashes:raise ValueError('Resume code differs; restore the frozen baseline files')
            self.meta=meta
            for line in (self.out/'actions.jsonl').read_text(encoding='utf-8').splitlines():
                event=json.loads(line)
                if event['event']=='request':self.records.append({'path':event['path'],'payload':event['payload'],'sent_wall':event['wall']})
                elif event['event']=='response':
                    found=next((r for r in reversed(self.records) if r['payload']['request_id']==event['request_id']),None)
                    if found is None:raise ValueError('Broken journal response')
                    found['response']=event['response']
            for r in self.records:
                if r['path']=='/enter' and r.get('response',{}).get('accepted'):
                    if live:self.deadline=r['sent_wall']+r['response']['remaining_real_duration_s']-settings['exit_reserve_s']
                    break
        else:
            if resume:raise ValueError('No prior session to resume')
            self.meta={'version':settings.get('version','baseline-v2.0'),'robot_id':robot_id,'settings_sha256':digest,'settings':settings,'code_sha256':code_hashes,'created':time.time()}
            save_json(manifest,self.meta)
        self._log=open(self.out/'actions.jsonl','a',encoding='utf-8')

    def _event(self,event):
        self._log.write(json.dumps(jsonable(event),ensure_ascii=False,allow_nan=False)+'\n');self._log.flush()
        os.fsync(self._log.fileno())

    def check_budget(self):
        if getattr(self, '_confirmed_replay_for_exit', False):return
        if self.live and time.time()>self.deadline:raise BudgetStop('real_time_budget')
        if self.measures+self.clear_attempts>=self.settings['max_actions']:raise BudgetStop('action_budget')
        if self.virtual_time>=self.max_virtual-10:raise BudgetStop('virtual_time_budget')

    def call(self,path,point=None,channel=None):
        base={'arena_id':'default','robot_id':self.robot_id}
        if point is not None:
            q=snap(point)
            if not np.isfinite(q).all() or np.max(np.abs(q))>2e6:raise ValueError('Invalid point')
            if type(channel)!=int or not 1<=channel<=20:raise ValueError('Invalid channel')
            base.update(position={'x':float(q[0]),'y':float(q[1])},channel=channel)
        if path not in ('/enter','/exit'):self.check_budget()
        if point is not None and not getattr(self, '_confirmed_replay_for_exit', False) and self.virtual_time+np.linalg.norm(q-self.p)/5+6>self.max_virtual-2:
            raise BudgetStop('next_action_exceeds_virtual_budget')
        if self.cursor<len(self.records):
            rec=self.records[self.cursor]
            same={k:v for k,v in rec['payload'].items() if k!='request_id'}
            if rec['path']!=path or same!=base:raise ProtocolError('Replay diverged; do not send a new action')
        else:
            if getattr(self, '_confirmed_replay_for_exit', False):
                raise ProtocolError('Exit replay cannot create a new physical action')
            rec={'path':path,'payload':dict(base,request_id=f'v2-{uuid.uuid4().hex}'),'sent_wall':time.time()}
            self.records.append(rec);self._event(dict(event='request',path=path,payload=rec['payload'],wall=rec['sent_wall']))
        self.pending=True
        if 'response' not in rec:
            response=self.backend.exchange(path,rec['payload'])
            rec['response']=response
            self._event(dict(event='response',request_id=rec['payload']['request_id'],response=response,wall=time.time()))
        response=rec['response']
        if response.get('accepted') is not True:
            # Do not adopt virtual_time_s=0 on rejected requests.
            raise ProtocolError('accepted=false: action not executed; inspect request/team/session')
        t=response.get('virtual_time_s')
        if not isinstance(t,(int,float)) or isinstance(t,bool) or not math.isfinite(t) or t+1e-5<self.virtual_time:
            raise ProtocolError('Invalid or decreasing virtual clock')
        if path=='/measure':
            result=response.get('measure_result')
            if result not in ('direction','near','no_signal'):raise ProtocolError('Unknown measure_result')
            if result=='direction':
                theta=response.get('svd_deg')
                if isinstance(theta,bool) or not isinstance(theta,(int,float)) or not math.isfinite(theta) or not 0<=theta<360:
                    raise ProtocolError('Invalid svd_deg')
                if abs(theta*100-round(theta*100))>1e-7:
                    raise ProtocolError('svd_deg violates the documented 0.01-degree response grid')
            self.measures+=1;self.switches+=int(channel!=self.channel);self.channel=channel
        elif path=='/clear':
            if response.get('clear_result') not in ('success','no_target_in_range'):raise ProtocolError('Invalid clear_result')
            self.clear_attempts+=1;self.successes+=int(response['clear_result']=='success')
        elif path=='/enter':
            self.max_virtual=float(response['max_virtual_duration_s'])
            if self.live:self.deadline=rec['sent_wall']+float(response['remaining_real_duration_s'])-self.settings['exit_reserve_s']
        if point is not None:self.movement+=float(np.linalg.norm(q-self.p));self.p=q
        self.virtual_time=float(t);self.cursor+=1;self.pending=False
        return response

    def drain_confirmed_replay_for_exit(self):
        """Adopt already accepted journal replies before a fresh /exit.

        No physical action is replayed and no unresolved request is bypassed.
        This lets a resumed run stop after its wall-clock budget has expired.
        """
        remaining=self.records[self.cursor:]
        if any(r.get('response',{}).get('accepted') is not True for r in remaining):
            self.pending=True
            return False
        self._confirmed_replay_for_exit=True
        try:
            while self.cursor<len(self.records):
                rec=self.records[self.cursor];payload=rec['payload']
                p=payload.get('position')
                self.call(rec['path'], None if p is None else (p['x'],p['y']), payload.get('channel'))
        finally:self._confirmed_replay_for_exit=False
        return True

    def close(self):self._log.close()


@dataclass
class Channel:
    state:str='UNKNOWN'
    history:History=field(default_factory=History)
    followups:int=0
    discovery:int=-1
    anchors:list=field(default_factory=list)
    reason:str=''


class Controller:
    """Frozen v1.0 control flow. No truth access and no old v2 opportunity heuristics."""
    def __init__(self,client,config):
        self.client=client;self.cfg=config;self.route=np.asarray(config['points'],dtype=float)
        self.channels={k:Channel() for k in range(1,21)};self.events=[];self.discovery=0
        self.current_anchor=-1;self.seen=set();self.reason='not_started';self.cert=None

    def event(self,kind,**data):
        self.events.append(dict(kind=kind,anchor=self.current_anchor,virtual_time_s=self.client.virtual_time,**jsonable(data)))

    def unresolved(self,k,reason):
        ch=self.channels[k];ch.state='UNRESOLVED';ch.reason=reason
        self.event('unresolved',channel=k,reason=reason)

    def measure(self,k,p,role):
        ch=self.channels[k];key=(k,point_key(p))
        if key in self.seen:raise PlanningError('Refusing same-location same-channel duplicate')
        reply=self.client.call('/measure',p,k);self.seen.add(key)
        if role=='target_followup':ch.followups+=1
        result=reply['measure_result'];self.event('measure',channel=k,point=snap(p),role=role,result=result)
        if result=='direction':
            if ch.state=='UNKNOWN':ch.discovery=self.discovery;self.discovery+=1
            ch.state='FOUND';ch.history.add_direction(p,reply['svd_deg'])
        elif result=='no_signal':
            ch.history.negatives.append(snap(p).tolist());ch.history.cached_plan=None
        elif result=='near':
            if ch.state=='UNKNOWN':ch.discovery=self.discovery;self.discovery+=1
            ch.state='FOUND';self.clear(k,p,reason='near')
        return result

    def clear(self,k,p,reason,certificate=None):
        reply=self.client.call('/clear',p,k);success=reply['clear_result']=='success'
        self.event('clear',channel=k,point=snap(p),reason=reason,success=success,certificate=certificate)
        ch=self.channels[k]
        if success:ch.state='CLEARED';ch.reason=''
        else:
            ch.history.failed_clears.append(snap(p).tolist())
            self.unresolved(k,'certified_clear_failed_inspect_data_or_model')
        return success

    def scan_anchor(self,i):
        self.current_anchor=i;point=self.route[i];self.event('anchor_start',index=i,point=point)
        # All currently UNKNOWN, numeric order. Original origin batch therefore 1..20.
        for k in range(1,21):
            ch=self.channels[k]
            if ch.state!='UNKNOWN':continue
            self.measure(k,point,'anchor_scan');ch.anchors.append(i)
        self.event('anchor_end',index=i)

    def get_plan(self,k):
        ch=self.channels[k]
        try:
            c=clearance(ch.history)
            if c is not None:return {'kind':'clear',**c}
            if ch.followups>=self.cfg['max_followups']:
                self.unresolved(k,'followup_limit');return None
            plan=plan_next(ch.history,self.cfg,self.client.check_budget)
            self.event('q2_plan',channel=k,plan=plan)
            return {'kind':'measure',**plan}
        except PlanningError as exc:
            self.unresolved(k,str(exc));return None

    def pick_for_leg(self,i):
        # q2 output is independent of route. Map it to nearest REMAINING skeleton leg.
        options=[]
        for k,ch in self.channels.items():
            if ch.state!='FOUND':continue
            plan=self.get_plan(k)
            if plan is None:continue
            q=np.asarray(plan['point'])
            candidates=[(*segment_distance(q,self.route[j],self.route[j+1]),j) for j in range(i,len(self.route)-1)]
            d,t,j=min(candidates,key=lambda z:(z[0],z[2]))
            if j!=i or d>self.cfg['corridor_m']:continue
            a,b=self.route[i],self.route[i+1]
            detour=float(np.linalg.norm(a-q)+np.linalg.norm(q-b)-np.linalg.norm(a-b))
            options.append((detour,k,plan,d,t))
        if not options:return None
        detour,k,plan,d,t=min(options,key=lambda z:(z[0],z[1]))
        self.event('insert',channel=k,leg=i,distance_to_leg_m=d,projection_fraction=t,
                   measurement_only_detour_m=detour,next_anchor=i+1)
        return k,plan

    def service(self,k,first_plan=None,tail=False):
        self.event('service_start',channel=k,tail=tail)
        ch=self.channels[k];plan=first_plan
        # Lifetime limit, including no_signal followups; never reset per route segment.
        while ch.state=='FOUND':
            if plan is None:plan=self.get_plan(k)
            if plan is None:break
            if plan['kind']=='clear':
                self.clear(k,plan['point'],'mec',plan);break
            if ch.followups>=self.cfg['max_followups']:
                self.unresolved(k,'followup_limit');break
            outcome=self.measure(k,plan['point'],'target_followup')
            if outcome=='no_signal':
                self.unresolved(k,'no_signal_at_receiver_certified_point');break
            if ch.state!='FOUND':break  # near already cleared
            # Check actual accumulated P after EVERY new bearing, before limit check.
            try:
                cert=clearance(ch.history)
                if cert is not None:self.clear(k,cert['point'],'mec',cert);break
            except PlanningError as exc:
                self.unresolved(k,str(exc));break
            plan=None
        self.event('service_end',channel=k,state=ch.state,tail=tail)
        # NO measurements of any other channel at source/clearance/target positions.

    def run(self):
        self.cert=exact_route_certificate(self.route)
        if not self.cert['certified']:raise PlanningError('Coverage skeleton has no certificate')
        self.client.call('/enter');self.reason='running'
        try:
            for i in range(len(self.route)):
                self.scan_anchor(i)
                if i<len(self.route)-1:
                    chosen=self.pick_for_leg(i)
                    if chosen:self.service(*chosen)
                # Exactly one serviced channel per leg. Next executed batch is next anchor.
            for ch in self.channels.values():
                if ch.state=='UNKNOWN':
                    if set(ch.anchors)==set(range(len(self.route))):ch.state='EMPTY_CERTIFIED'
                    else:ch.reason='incomplete_anchor_coverage'
            # Mandatory finite tail: channels missed by the corridor are not forgotten.
            tail=sorted((ch.discovery,k) for k,ch in self.channels.items() if ch.state=='FOUND')
            for _,k in tail:self.service(k,tail=True)
            self.reason='completed' if all(ch.state in ('CLEARED','EMPTY_CERTIFIED') for ch in self.channels.values()) else 'incomplete_unresolved'
        except BudgetStop as exc:self.reason=f'budget_stop:{exc}'
        except (ProtocolError,UncertainAction):
            self.reason='communication_stopped';raise
        finally:
            if self.reason not in ('communication_stopped','running') and not self.client.pending:
                try:self.client.call('/exit')
                except ProtocolError:self.reason+=';exit_not_confirmed'
        return self.summary()

    def summary(self):
        m=self.client
        return {'version':'baseline-v1.0','route':self.cfg['route_name'],'completion':self.reason,
            'known_cleared':sum(c.state=='CLEARED' for c in self.channels.values()),
            'unresolved_channels':[k for k,c in self.channels.items() if c.state in ('FOUND','UNRESOLVED','UNKNOWN')],
            'virtual_time_s':m.virtual_time,'movement_m':m.movement,'measures':m.measures,
            'switches':m.switches,'clear_attempts':m.clear_attempts,'successes':m.successes,
            'time_equation_s':m.movement/5+5*m.measures+m.switches+3*m.clear_attempts+2*m.successes,
            'mean_time_per_cleared_s':m.virtual_time/m.successes if m.successes else None,
            'official_clearance_ratio':None, # True N is not supplied to the online policy.
            'coverage_certificate':self.cert,
            'channel_states':{k:{'state':c.state,'followups':c.followups,'reason':c.reason,'anchors':c.anchors,
                'observations':c.history.observations,'negatives':c.history.negatives} for k,c in self.channels.items()}}


def synthetic_scene(seed,kind='uniform',n=None):
    rng=np.random.default_rng(seed);n=int(rng.integers(10,17)) if n is None else int(n)
    channels=rng.choice(np.arange(1,21),size=n,replace=False);sources=[]
    centres=[]
    for _ in range(3):
        a=rng.uniform(0,2*math.pi);r=rng.uniform(300,1400);centres.append(r*np.array([math.cos(a),math.sin(a)]))
    for j,k in enumerate(channels):
        if kind=='clustered':
            p=centres[j%3]+rng.normal(0,130,size=2)
            if np.linalg.norm(p)>1799:p*=1799/np.linalg.norm(p)
        else:
            a=rng.uniform(0,2*math.pi)
            r=1800*np.sqrt(rng.uniform()) if kind=='uniform' else rng.uniform(1690,1800)
            p=r*np.array([math.cos(a),math.sin(a)])
        radius=1000. if kind=='rim' or seed%2==0 else float(rng.uniform(1000,1500))
        sources.append({'channel':int(k),'position':p.tolist(),'radius':radius})
    return {'seed':int(seed),'kind':kind,'sources':sources,'source_distribution':'synthetic only; not official generation law'}


def execute(config,out,backend,robot_id='OFFLINE',resume=False,live=False):
    client=JournalClient(backend,out,robot_id,config,resume,live);controller=Controller(client,config)
    started=time.perf_counter();error=None
    try:result=controller.run()
    except KeyboardInterrupt:
        controller.reason='interrupted_resume_required';error='KeyboardInterrupt';result=controller.summary();result['error']=error
    except Exception as exc:
        error=f'{type(exc).__name__}: {exc}';result=controller.summary();result['error']=error
    finally:
        result['wall_runtime_s']=time.perf_counter()-started
        save_json(Path(out)/'summary.json',result);save_json(Path(out)/'decisions.json',controller.events)
        client.close()
    return result,error


def selftest(config,out):
    """Executed local tests, including an HTTP loopback protocol mock."""
    import unittest
    import threading
    from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
    from fractions import Fraction as F
    from solver import exact_enclosing_circle,certify_reception,ALPHA,sampled_worst,halfplanes
    from 第一问 import localize,run_tests
    import tempfile
    class Tests(unittest.TestCase):
        def test_01_q1_regression(self):run_tests()
        def test_02_route_certificate(self):self.assertTrue(exact_route_certificate(config['points'])['certified'])
        def test_03_equilateral_mec(self):
            v=[(F(0),F(0)),(F(36),F(0)),(F(18),F(str(18*math.sqrt(3))))]
            _,r2=exact_enclosing_circle(v);self.assertGreater(r2,400);self.assertAlmostEqual(float(r2),432,places=8)
        def test_04_point_and_segment(self):
            self.assertEqual(exact_enclosing_circle([(F(1),F(2))])[1],0)
            self.assertEqual(exact_enclosing_circle([(F(0),F(0)),(F(10),F(0))])[1],25)
        def test_05_receiver_witness(self):
            h=History(observations=[(0.,0.,0.)]);q=[450.,900*math.sin(math.pi/3)]
            self.assertTrue(certify_reception(h,q)['certified'])
        def test_06_receiver_reject(self):
            h=History(observations=[(0.,0.,0.)]);self.assertFalse(certify_reception(h,[-1000.,0.],max_cells=1000)['certified'])
        def test_07_same_location(self):
            h=History();h.add_direction([0,0],1)
            with self.assertRaises(PlanningError):h.add_direction([0,0],1.1)
        def test_08_projection(self):
            d,t=segment_distance([5,3],[0,0],[10,0]);self.assertEqual(d,3);self.assertEqual(t,.5)
            self.assertEqual(segment_distance([-3,0],[0,0],[10,0]),(3.,0.))
        def test_09_api_time_and_channel(self):
            b=OfflineBackend({'seed':1,'sources':[]});base={'arena_id':'default','robot_id':'x'}
            b.exchange('/enter',dict(base,request_id='1'))
            r=b.exchange('/measure',dict(base,request_id='2',position={'x':300,'y':400},channel=1));self.assertEqual(r['virtual_time_s'],105)
            r=b.exchange('/measure',dict(base,request_id='3',position={'x':300,'y':400},channel=2));self.assertEqual(r['virtual_time_s'],111)
            r=b.exchange('/clear',dict(base,request_id='4',position={'x':300,'y':0},channel=3));self.assertEqual(r['virtual_time_s'],194)
            r=b.exchange('/measure',dict(base,request_id='5',position={'x':300,'y':0},channel=2));self.assertEqual(r['virtual_time_s'],199)
        def test_10_idempotency(self):
            b=OfflineBackend({'seed':1,'sources':[]});p={'arena_id':'default','robot_id':'x','request_id':'1'}
            b.exchange('/enter',p);p=dict(p,request_id='2',position={'x':0,'y':0},channel=1)
            a=b.exchange('/measure',p);self.assertEqual(a,b.exchange('/measure',p));self.assertEqual(b.evaluation()['measures'],1)
            with self.assertRaises(ProtocolError):b.exchange('/measure',dict(p,channel=2))
        def test_11_near(self):
            b=OfflineBackend({'seed':1,'sources':[{'channel':1,'position':[3,4],'radius':1000}]});p={'arena_id':'default','robot_id':'x','request_id':'1'}
            b.exchange('/enter',p);r=b.exchange('/measure',dict(p,request_id='2',position={'x':0,'y':0},channel=1))
            self.assertEqual(r['measure_result'],'near');self.assertNotIn('svd_deg',r)
        def test_12_5_to_20(self):
            b=OfflineBackend({'seed':1,'sources':[{'channel':1,'position':[10,0],'radius':1000}]});p={'arena_id':'default','robot_id':'x','request_id':'1'}
            b.exchange('/enter',p);r=b.exchange('/measure',dict(p,request_id='2',position={'x':0,'y':0},channel=1));self.assertEqual(r['measure_result'],'direction')
        def test_13_full_unknown_sweep_zero_origin_signals(self):
            # No sources is a deliberate controller boundary unit test, not a legal Q3 scene.
            with tempfile.TemporaryDirectory() as d:
                b=OfflineBackend({'seed':1,'sources':[]});r,e=execute(config,d,b)
                self.assertIsNone(e);self.assertEqual(r['measures'],20*len(config['points']))
                self.assertEqual(r['completion'],'completed');self.assertEqual(r['known_cleared'],0)
                events=json.loads((Path(d)/'decisions.json').read_text())
                initial=[x['channel'] for x in events if x['kind']=='measure' and x['anchor']==0]
                self.assertEqual(initial,list(range(1,21)))
        def test_14_iteration_cap(self):
            cfg=dict(config,max_followups=0)
            with tempfile.TemporaryDirectory() as d:
                b=OfflineBackend({'seed':2,'sources':[{'channel':1,'position':[500,500],'radius':1000}]})
                r,e=execute(cfg,d,b);self.assertIsNone(e);self.assertEqual(r['channel_states'][1]['followups'],0)
                self.assertIn(1,r['unresolved_channels']);self.assertNotEqual(r['completion'],'completed')
        def test_15_resume_no_reexecution(self):
            with tempfile.TemporaryDirectory() as d:
                b=OfflineBackend({'seed':1,'sources':[]});r,e=execute(config,d,b)
                before=b.evaluation();rr,ee=execute(config,d,b,resume=True)
                self.assertIsNone(ee);self.assertEqual(before,b.evaluation());self.assertEqual(r['virtual_time_s'],rr['virtual_time_s'])
        def test_16_http_roundtrip(self):
            b=OfflineBackend({'seed':1,'sources':[]})
            class Handler(BaseHTTPRequestHandler):
                def do_POST(self):
                    p=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                    r=b.exchange(self.path,p);data=json.dumps(r).encode()
                    self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
                def log_message(self,*args):pass
            server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            try:
                c=LiveBackend(f'http://127.0.0.1:{server.server_port}')
                r=c.exchange('/enter',{'arena_id':'default','robot_id':'x','request_id':'1'});self.assertTrue(r['accepted'])
            finally:server.shutdown();server.server_close();thread.join()
        def test_17_unknown_field_not_accepted(self):
            b=OfflineBackend({'seed':1,'sources':[]});r=b.exchange('/enter',{'arena_id':'default','robot_id':'x','request_id':'1','extra':2});self.assertFalse(r['accepted'])
        def test_18_no_clear_of_unbounded(self):
            self.assertIsNone(clearance(History(observations=[(0,0,1)])))
        def test_19_valid_clear_certificate(self):
            c=clearance(History(observations=[(0,0,45.4),(1000,0,134.3)]));self.assertIsNotNone(c);self.assertLessEqual(c['command_cover_radius_m'],20)
        def test_20_same_location_error_is_fixed(self):
            b=OfflineBackend({'seed':23,'sources':[{'channel':1,'position':[600,300],'radius':1000}]})
            base={'arena_id':'default','robot_id':'x'};b.exchange('/enter',dict(base,request_id='e'))
            a=b.exchange('/measure',dict(base,request_id='a',position={'x':0,'y':0},channel=1))
            z=b.exchange('/measure',dict(base,request_id='b',position={'x':0,'y':0},channel=1))
            self.assertEqual(a['svd_deg'],z['svd_deg']);self.assertEqual(z['virtual_time_s'],10)
        def test_21_legal_rim_can_have_zero_signals_at_origin(self):
            cfg=dict(config,max_followups=0)
            with tempfile.TemporaryDirectory() as d:
                b=OfflineBackend(synthetic_scene(101,'rim',10));r,e=execute(cfg,d,b)
                self.assertIsNone(e)
                ev=json.loads((Path(d)/'decisions.json').read_text())
                origin=[x for x in ev if x['kind']=='measure' and x['anchor']==0]
                self.assertEqual(len(origin),20);self.assertTrue(all(x['result']=='no_signal' for x in origin))
                self.assertEqual(sum(c['state']=='UNRESOLVED' for c in r['channel_states'].values()),10)
        def test_22_reject_does_not_move(self):
            class Reject:
                def exchange(self,path,payload):return {'accepted':False,'virtual_time_s':0,'real_timestamp_ms':0}
            with tempfile.TemporaryDirectory() as d:
                c=JournalClient(Reject(),d,'x',config)
                try:
                    with self.assertRaises(ProtocolError):c.call('/measure',[300,400],2)
                    self.assertEqual(c.movement,0);self.assertEqual(c.measures,0);self.assertEqual(c.channel,1)
                finally:c.close()
        def test_23_http_lost_response_reuses_identical_request(self):
            b=OfflineBackend({'seed':1,'sources':[]});seen=[]
            class Handler(BaseHTTPRequestHandler):
                def do_POST(self):
                    body=self.rfile.read(int(self.headers['Content-Length']));seen.append(body)
                    p=json.loads(body);r=b.exchange(self.path,p)
                    if len(seen)==1:
                        self.close_connection=True;self.connection.close();return
                    data=json.dumps(r).encode();self.send_response(200);self.send_header('Content-Length',str(len(data)))
                    self.end_headers();self.wfile.write(data)
                def log_message(self,*args):pass
            server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            try:
                c=LiveBackend(f'http://127.0.0.1:{server.server_port}',timeout=1,retries=2)
                r=c.exchange('/enter',{'arena_id':'default','robot_id':'x','request_id':'recover'})
                self.assertTrue(r['accepted']);self.assertGreaterEqual(len(seen),2);self.assertEqual(seen[0],seen[1])
            finally:server.shutdown();server.server_close();thread.join()
        def test_24_tail_does_not_drop_distant_source(self):
            # A synthetic zero-noise pair makes a finite <=20m polygon after the follow-up.
            # The second point is forced outside the zero-width skeleton corridor.
            global plan_next
            original=plan_next
            def stub(hist,cfg,check):return {'point':[500.,400.],'optimality':'unit-test stub'}
            plan_next=stub
            class Fixed(OfflineBackend):
                def exchange(self,path,payload):
                    r=super().exchange(path,payload)
                    if path=='/measure' and r.get('measure_result')=='direction':
                        q=payload['position'];t=math.degrees(math.atan2(500-q['y'],500-q['x']))%360
                        r=dict(r,svd_deg=t)
                    return r
            try:
                cfg=dict(config,corridor_m=0.)
                with tempfile.TemporaryDirectory() as d:
                    b=Fixed({'seed':1,'sources':[{'channel':1,'position':[500,500],'radius':1000}]})
                    r,e=execute(cfg,d,b);self.assertIsNone(e);self.assertEqual(r['known_cleared'],1)
                    events=json.loads((Path(d)/'decisions.json').read_text())
                    tails=[x for x in events if x['kind']=='service_start' and x['tail']]
                    self.assertEqual(len(tails),1)
                    follow=[x for x in events if x['kind']=='measure' and x['role']=='target_followup']
                    self.assertTrue(all(x['channel']==1 for x in follow))
                    anchor_scans=[x for x in events if x['kind']=='measure' and x['role']=='anchor_scan' and x['anchor']>0]
                    self.assertTrue(all(x['channel']!=1 for x in anchor_scans))
                    clears=[i for i,x in enumerate(events) if x['kind']=='clear']
                    self.assertTrue(clears)
                    self.assertFalse(any(x['kind']=='measure' for x in events[clears[-1]+1:]))
            finally:plan_next=original
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),
            'official_simulator_tested':False,'details':[str(x) for x in result.failures+result.errors]}
    Path(out).mkdir(parents=True,exist_ok=True);save_json(Path(out)/'tests.json',report)
    return 0 if result.wasSuccessful() else 1


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mode',choices=['offline','live','experiment','selftest','routecheck','design-spiral'],default='offline')
    ap.add_argument('--config',default=str(HERE/'config.json'))
    ap.add_argument('--out',default=None);ap.add_argument('--robot-id',default=None)
    ap.add_argument('--url',default='http://127.0.0.1:2026');ap.add_argument('--resume',action='store_true')
    ap.add_argument('--seed',type=int,default=20260912);ap.add_argument('--scene',choices=['uniform','clustered','rim'],default='uniform')
    ap.add_argument('--starts',type=int,default=10)
    ap.add_argument('--trials',type=int,default=12);ap.add_argument('--corridor-m',type=float);ap.add_argument('--max-followups',type=int)
    args=ap.parse_args();cfg=json.loads(Path(args.config).read_text(encoding='utf-8'))
    if args.corridor_m is not None:cfg['corridor_m']=args.corridor_m
    if args.max_followups is not None:cfg['max_followups']=args.max_followups
    if cfg['max_followups']<0 or cfg['corridor_m']<0:raise ValueError('Negative limit')
    out=Path(args.out) if args.out else HERE/'runs'/f'{args.mode}_{time.strftime("%Y%m%d_%H%M%S")}_{uuid.uuid4().hex[:6]}'
    if args.mode=='routecheck':
        out.mkdir(parents=True,exist_ok=True);r=exact_route_certificate(cfg['points']);save_json(out/'route_certificate.json',r);print(json.dumps(r,ensure_ascii=False,indent=2));return int(not r['certified'])
    if args.mode=='design-spiral':
        from solver import regenerate_spiral
        out.mkdir(parents=True,exist_ok=True);r=regenerate_spiral(args.starts);save_json(out/'spiral_design.json',r)
        print('Offline design saved:',out/'spiral_design.json');return int(r['best'] is None)
    if args.resume and args.mode!='live':ap.error('--resume is supported only for a still-active LIVE session')
    warmup()
    if args.mode=='selftest':return selftest(cfg,out)
    if args.mode=='live':
        if not args.robot_id or args.robot_id.startswith('<'):ap.error('--robot-id must be your actual logged-in team number')
        backend=LiveBackend(args.url,cfg['http_timeout_s'],cfg['http_retries'])
        print('LIVE: only run after the official PRACTICE interface is ready. This program does not start a GUI test.')
        r,e=execute(cfg,out,backend,args.robot_id,args.resume,True)
    elif args.mode=='offline':
        scene=synthetic_scene(args.seed,args.scene);backend=OfflineBackend(scene)
        out.mkdir(parents=True,exist_ok=True)
        r,e=execute(cfg,out,backend,resume=args.resume)
        r['offline_evaluation']=backend.evaluation();save_json(out/'summary.json',r);save_json(out/'scene.json',scene)
    else:
        if args.trials<1:raise ValueError('trials must be positive')
        rows=[];out.mkdir(parents=True,exist_ok=True)
        for j in range(args.trials):
            kind=['uniform','clustered','rim'][j%3];seed=args.seed+j;scene=synthetic_scene(seed,kind);backend=OfflineBackend(scene)
            dst=out/f'{j:03d}_{kind}_{seed}';r,e=execute(cfg,dst,backend)
            ev=backend.evaluation();r['offline_evaluation']=ev;save_json(dst/'summary.json',r);save_json(dst/'scene.json',scene)
            row={k:r[k] for k in ['route','completion','virtual_time_s','movement_m','measures','switches','clear_attempts','successes','wall_runtime_s']}
            row.update(seed=seed,kind=kind,source_count=ev['actual_source_count'],clearance_ratio=ev['clearance_ratio'],error=e or '')
            rows.append(row);print(f'{j+1}/{args.trials}: {kind}, {ev["actual_cleared_count"]}/{ev["actual_source_count"]}, {r["virtual_time_s"]/60:.2f} virtual min',flush=True)
        with (out/'results.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        agg={'route':cfg['route_name'],'trials':len(rows),'completed':sum(x['completion']=='completed' for x in rows),
            'mean_virtual_minutes':float(np.mean([x['virtual_time_s']/60 for x in rows])),
            'mean_clearance_ratio':float(np.mean([x['clearance_ratio'] for x in rows])),
            'official_simulator_tested':False}
        save_json(out/'experiment_summary.json',agg);print(json.dumps(agg,ensure_ascii=False,indent=2));return 0
    print(json.dumps({k:r.get(k) for k in ['route','completion','known_cleared','unresolved_channels','virtual_time_s','wall_runtime_s','error']},ensure_ascii=False,indent=2))
    print('Outputs:',out)
    return 1 if e or r['completion']!='completed' else 0


if __name__=='__main__':
    raise SystemExit('This file provides reused v1 runtime classes. Run: python run.py --mode offline')
