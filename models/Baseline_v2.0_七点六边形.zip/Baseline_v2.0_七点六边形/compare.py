#!/usr/bin/env python3
"""Replay saved v1 scenes exactly; compare complete v2 runs with v1 records."""
import argparse
import csv
import json
from pathlib import Path
from run import HERE, run_case, warmup, prepare_geometry, save_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--scenes',type=Path,default=HERE/'validation/reference_scenes')
    p.add_argument('--baseline-csv',type=Path,default=HERE/'validation/reference_v1.csv')
    p.add_argument('--config',type=Path,default=HERE/'config.json')
    p.add_argument('--out',type=Path,default=Path('runs/paired_exact'))
    a=p.parse_args()
    cfg=json.loads(a.config.read_text())
    original={int(r['seed']):r for r in csv.DictReader(a.baseline_csv.open(encoding='utf-8-sig'))}
    files=sorted(a.scenes.glob('*/scene.json'))
    if not files:raise SystemExit('No saved scenes found')
    warmup();prepare_geometry(cfg)
    a.out.mkdir(parents=True,exist_ok=True);rows=[]
    for i,f in enumerate(files):
        scene=json.loads(f.read_text())
        result=run_case(cfg,a.out/f.parent.name,scene)
        e=result['offline_evaluation'];old=original[scene['seed']]
        row=dict(trial=i,seed=scene['seed'],kind=scene['kind'],completion=result['completion'],
            actual_source_count=e['actual_source_count'],actual_cleared_count=e['actual_cleared_count'],
            clearance_ratio=e['clearance_ratio'],virtual_time_s=e['virtual_time_s'],
            movement_m=e['movement_m'],measures=e['measures'],switches=e['switches'],
            clear_attempts=e['clear_attempts'],wall_elapsed_s=result['wall_elapsed_s'],
            v1_virtual_time_s=float(old['virtual_time_s']))
        rows.append(row)
        with (a.out/'results.csv').open('w',newline='',encoding='utf-8') as out:
            writer=csv.DictWriter(out,fieldnames=row);writer.writeheader();writer.writerows(rows)
        print(json.dumps(row,ensure_ascii=False),flush=True)
    save_json(a.out/'experiment_summary.json',dict(version=cfg['version'],
        scene_source='saved v1 records; no scene regeneration',trials=rows))
    raise SystemExit(0 if all(r['completion']=='completed' for r in rows) else 1)


if __name__=='__main__':main()
