"""Baseline v1.0 geometry and sampled Q2 optimizer.
P is pure bearing geometry; F_outer is used ONLY for sampling and candidate generation.
Actual clearance is rechecked against Q1 Fraction vertices, not a clipped P.
Q2 follows repository main@2ba4b25a, sections/问题二.tex; not a copied Q2 program.
"""
from __future__ import annotations
import math
import itertools
import numpy as np
try:
    from numba import njit
except ImportError:
    def njit(*args, **kwargs):
        return lambda fn: fn
ALPHA=math.pi/180

@njit(cache=True)
def clip(poly,hx,hy,c):
    n=len(poly)
    out=np.empty((2*n+2,2)); z=0
    for i in range(n):
        p=poly[i];q=poly[(i+1)%n]
        a=hx*p[0]+hy*p[1]-c;b=hx*q[0]+hy*q[1]-c
        # Only tiny floating residual tolerance; no physical alpha inflation.
        if a<=1e-9:
            out[z]=p;z+=1
        if (a<0<b) or (b<0<a):
            out[z]=p+a/(a-b)*(q-p);z+=1
    if z==0:return out[:0]
    nn=1
    for i in range(1,z):
        if np.sum((out[i]-out[nn-1])**2)>1e-16:
            out[nn]=out[i];nn+=1
    if nn>1 and np.sum((out[0]-out[nn-1])**2)<1e-16:nn-=1
    return out[:nn].copy()

@njit(cache=True)
def add_wedge(poly,p,t,alpha=ALPHA):
    for lo in range(2):
        if lo==0:hx=math.sin(t-alpha);hy=-math.cos(t-alpha)
        else:hx=-math.sin(t+alpha);hy=math.cos(t+alpha)
        poly=clip(poly,hx,hy,hx*p[0]+hy*p[1])
    return poly

def outer_disk(p,r,n=48):
    a=(np.arange(n)+.5)*2*math.pi/n
    return np.asarray(p)+r/math.cos(math.pi/n)*np.column_stack((np.cos(a),np.sin(a)))

@njit(cache=True)
def add_rx_outer(poly,p,r=1500.,n=32):
    for j in range(n):
        t=j*2*math.pi/n;hx=math.cos(t);hy=math.sin(t)
        poly=clip(poly,hx,hy,hx*p[0]+hy*p[1]+r)
    return poly

@njit(cache=True)
def maxdist(v,c):
    a=0.
    for i in range(len(v)):a=max(a,np.sum((v[i]-c)**2))
    return math.sqrt(a)

@njit(cache=True)
def enclosing(v):
    """Enumeration of 1/2/3 support centres; final max distance recomputed."""
    c=np.zeros(2)
    for x in v:c+=x
    c/=len(v);r=maxdist(v,c)
    for i in range(len(v)):
        for j in range(i+1,len(v)):
            cc=(v[i]+v[j])/2;rr=maxdist(v,cc)
            if rr<r:c=cc;r=rr
            for k in range(j+1,len(v)):
                aa=2*(v[j]-v[i]);bb=2*(v[k]-v[i]);det=aa[0]*bb[1]-aa[1]*bb[0]
                if abs(det)<1e-9:continue
                u=np.sum(v[j]**2)-np.sum(v[i]**2);w=np.sum(v[k]**2)-np.sum(v[i]**2)
                cc=np.array([(u*bb[1]-aa[1]*w)/det,(aa[0]*w-u*bb[0])/det])
                rr=maxdist(v,cc)
                if rr<r:c=cc;r=rr
    return c,r

@njit(cache=True)
def diameter(v):
    b=0.
    for i in range(len(v)):
        for j in range(i+1,len(v)):b=max(b,np.sum((v[i]-v[j])**2))
    return math.sqrt(b)

@njit(cache=True)
def pure_diameter(h,c):
    """Returns inf for common recession direction, nan for empty.
    In this function generated observations share a true rehearsal point, so
    nonemptiness follows mathematically; emptiness is still explicitly flagged.
    """
    n=len(c)
    for k in range(n):
        for s in [-1.,1.]:
            dx=-s*h[k,1];dy=s*h[k,0];ok=True
            for i in range(n):
                if h[i,0]*dx+h[i,1]*dy>1e-13:ok=False;break
            if ok:return math.inf
    out=np.empty((n*n,2));m=0
    for i in range(n):
        for j in range(i+1,n):
            det=h[i,0]*h[j,1]-h[i,1]*h[j,0]
            if abs(det)<1e-14:continue
            x=(c[i]*h[j,1]-h[i,1]*c[j])/det
            y=(h[i,0]*c[j]-c[i]*h[j,0])/det
            ok=True
            for t in range(n):
                if h[t,0]*x+h[t,1]*y>c[t]+1e-6:ok=False;break
            if ok:out[m,0]=x;out[m,1]=y;m+=1
    if m==0:return math.nan
    return diameter(out[:m])

def halfplanes(obs):
    h=[];c=[]
    for x,y,tdeg in obs:
        t=math.radians(tdeg)
        for hh in [(math.sin(t-ALPHA),-math.cos(t-ALPHA)),(-math.sin(t+ALPHA),math.cos(t+ALPHA))]:
            h.append(hh);c.append(hh[0]*x+hh[1]*y)
    return np.array(h),np.array(c)

@njit(cache=True)
def sampled_worst(q,h,c,scenario,errors):
    hh=np.empty((len(c)+2,2));cc=np.empty(len(c)+2)
    hh[:-2]=h;cc[:-2]=c;b=0.
    for g in scenario:
        d=g-q
        if np.sum(d*d)<=25:continue
        beta=math.atan2(d[1],d[0])
        for e in errors:
            t=beta+e
            hh[-2,0]=math.sin(t-ALPHA);hh[-2,1]=-math.cos(t-ALPHA)
            hh[-1,0]=-math.sin(t+ALPHA);hh[-1,1]=math.cos(t+ALPHA)
            cc[-2]=np.sum(hh[-2]*q);cc[-1]=np.sum(hh[-1]*q)
            x=pure_diameter(hh,cc)
            if math.isnan(x):return math.nan
            b=max(b,x)
            if math.isinf(b):return b
    return b

def longest_normal(v):
    d=v[:,None,:]-v[None,:,:];ij=np.unravel_index(np.argmax(np.sum(d*d,axis=2)),d.shape[:2]);z=v[ij[1]]-v[ij[0]]
    z/=max(np.linalg.norm(z),1e-10)
    return np.array([-z[1],z[0]])

# --- Baseline v1.0 additions: exact execution geometry, source history, Q2. ---
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path
from 第一问 import localize as exact_localize, build_halfplanes as exact_halfplanes


def point_key(p):
    return tuple(int(round(float(x)*1000)) for x in p)


def snap(p):
    return np.array(point_key(p), dtype=float)/1000.


class PlanningError(RuntimeError):
    pass


@dataclass
class History:
    observations: list = field(default_factory=list)  # (x,y,theta_deg), positive only
    negatives: list = field(default_factory=list)     # all earlier no_signal locations
    failed_clears: list = field(default_factory=list)
    cached_plan: dict | None = None

    def add_direction(self, p, theta):
        theta = float(theta) % 360.
        if not math.isfinite(theta):
            raise PlanningError('Non-finite bearing')
        if any(point_key(o[:2]) == point_key(p) for o in self.observations):
            raise PlanningError('Repeated measurement location: no new independent error allowed')
        self.observations.append((*map(float, snap(p)), theta))
        self.cached_plan = None

    def outer_polygon(self):
        """Convex outer enclosure, NOT P. Curved constraints are circumscribed.
        Near-excluded holes and radius correlations are checked in samples separately.
        """
        v = outer_disk(np.zeros(2), 1800., 64)
        for x,y,t in self.observations:
            p=np.array([x,y])
            v=add_rx_outer(add_wedge(v,p,math.radians(t)),p,n=48)
        for z in self.negatives:
            z=np.asarray(z)
            for o in self.observations:
                p=np.asarray(o[:2]); h=2*(z-p); c=float(z@z-p@p)
                v=clip(v,h[0],h[1],c)
        if not len(v):
            raise PlanningError('Positive-history outer set empty; inspect data/numerics')
        return v

    def compatible(self, x):
        """No random-position prior. This is a deterministic scenario feasibility test."""
        x=np.asarray(x); h,c=halfplanes(self.observations)
        if x@x>1800.**2 or np.any(h@x>c+1e-9):return False
        ds=np.array([np.linalg.norm(x-np.asarray(o[:2])) for o in self.observations])
        if not len(ds) or np.min(ds)<=5 or np.max(ds)>1500:return False
        rlo=max(1000.,float(np.max(ds)))
        if any(np.linalg.norm(x-np.asarray(z))<=rlo for z in self.negatives):return False
        if any(np.linalg.norm(x-np.asarray(z))<=20 for z in self.failed_clears):return False
        return True

    def scenarios(self, limit=49, dense=False):
        v=self.outer_polygon(); c=np.mean(v,axis=0)
        pool=[c]
        for z in v:
            for t in [0.01,.1,.3,.5,.8,.97,1.]:pool.append(c+t*(z-c))
        for a,b in zip(v,np.roll(v,-1,axis=0)):
            for t in [.1,.3,.5,.7,.9]:pool.append(a+t*(b-a))
        if len(self.observations)==1:
            x,y,td=self.observations[0]; base=np.array([x,y]); theta=math.radians(td)
            for r in np.linspace(5.001,1500.,101 if dense else 61):
                for d in np.linspace(-.999999*ALPHA,.999999*ALPHA,9 if dense else 5):
                    pool.append(base+r*np.array([math.cos(theta+d),math.sin(theta+d)]))
        # Deterministic Halton barycentric points: no state/probability assumption.
        def radical(i,base):
            x=0.;f=1.
            while i:
                f/=base;x+=(i%base)*f;i//=base
            return x
        for i in range(1,1801 if dense else 701):
            j=(i-1)%len(v); a=v[j];b=v[(j+1)%len(v)]
            u=math.sqrt(radical(i,2)); w=radical(i,3)
            pool.append((1-u)*c+u*(1-w)*a+u*w*b)
        accepted=[np.asarray(z) for z in pool if self.compatible(z)]
        if not accepted:
            raise PlanningError('No compatible source sample found; not a proof that F is empty')
        a=np.unique(np.asarray(accepted),axis=0)
        if len(a)<=limit:return a
        # Spread rather than only retaining a single row of a lexicographic grid.
        chosen=[int(np.argmax(np.linalg.norm(a-c,axis=1)))]; mins=np.full(len(a),np.inf)
        while len(chosen)<limit:
            mins=np.minimum(mins,np.sum((a-a[chosen[-1]])**2,axis=1));mins[chosen]=-1
            chosen.append(int(np.argmax(mins)))
        return a[chosen]


def exact_enclosing_circle(vertices):
    """Exhaustive 1/2/3 support-centre enumeration with Fraction arithmetic.
    Recomputing max distance for EVERY centre ensures no triangle acute/obtuse trap.
    """
    v=list(vertices)
    if not v:raise PlanningError('Empty set cannot be a zero-radius success')
    if len(v)==1:return v[0],Fraction(0)
    def d2(a,b):return (a[0]-b[0])**2+(a[1]-b[1])**2
    centres=[v[0]]
    for a,b in itertools.combinations(v,2):centres.append(((a[0]+b[0])/2,(a[1]+b[1])/2))
    for a,b,c in itertools.combinations(v,3):
        ux,uy=2*(b[0]-a[0]),2*(b[1]-a[1]);vx,vy=2*(c[0]-a[0]),2*(c[1]-a[1])
        det=ux*vy-uy*vx
        if not det:continue
        r=b[0]**2+b[1]**2-a[0]**2-a[1]**2;s=c[0]**2+c[1]**2-a[0]**2-a[1]**2
        centres.append(((r*vy-uy*s)/det,(ux*s-r*vx)/det))
    return min(((c,max(d2(z,c) for z in v)) for c in centres),key=lambda z:z[1])


def clearance(history):
    """Pure P only; never substitute F_outer. Check the ACTUAL millimetre command."""
    if not history.observations:return None
    r=exact_localize(history.observations)
    if r.status=='空集':raise PlanningError('Actual Q1 intersection empty; do not clear')
    if r.status=='无界':return None
    c,r2=exact_enclosing_circle(r.vertices)
    if r2>400:return None
    q=tuple(Fraction(k,1000) for k in point_key(c))
    actual_r2=max((z[0]-q[0])**2+(z[1]-q[1])**2 for z in r.vertices)
    if actual_r2>400:return None
    return {'point':[float(q[0]),float(q[1])], 'mec_radius_m':math.sqrt(float(r2)),
            'command_cover_radius_m':math.sqrt(float(actual_r2)),
            'q1_status':r.status,'diameter_m':r.diameter,
            'coverage_arithmetic':'Fraction; exact for Q1 rationalized coefficients'}


def _min_rect_d2(p, b):
    xl,xh,yl,yh=b;dx=max(xl-p[0],0,p[0]-xh);dy=max(yl-p[1],0,p[1]-yh)
    return dx*dx+dy*dy


def _max_rect_d2(p, b):
    xl,xh,yl,yh=b;dx=max(abs(xl-p[0]),abs(xh-p[0]));dy=max(abs(yl-p[1]),abs(yh-p[1]))
    return dx*dx+dy*dy


def certify_reception(history, q, max_cells=18000):
    """Continuous K outer-set certificate using exact integer distance bounds.
    Wedge pruning uses enclosing integer intervals for Q1 Fraction coefficients.
    Guarantee is for the Q1 rational coefficient model, not exact ideal sin/cos.
    Unresolved cells -> reject, NEVER accept a sampled-only reception claim.
    """
    pos=[point_key(o[:2]) for o in history.observations]; neg=[point_key(z) for z in history.negatives]
    qm=point_key(q); R2=1_500_000**2; L2=1_000_000**2
    scale=10**12; hh=[]
    for a,b,c in exact_halfplanes(history.observations):
        # metre equation becomes a*x_mm+b*y_mm <= 1000*c.
        def bounds(x):
            z=x*scale; lo=z.numerator//z.denominator;hi=-((-z.numerator)//z.denominator)
            return lo,hi
        aa=bounds(a);bb=bounds(b);cc=bounds(1000*c)
        hh.append((*aa,*bb,cc[1]))
    stack=[(-1_800_000,1_800_000,-1_800_000,1_800_000)]; seen=0; leaves=0
    while stack:
        box=stack.pop();seen+=1
        if seen>max_cells:return {'certified':False,'reason':'cell_budget','cells':seen}
        xl,xh,yl,yh=box
        if _min_rect_d2((0,0),box)>1_800_000**2:continue
        dsmin=[_min_rect_d2(p,box) for p in pos]
        if any(d>R2 for d in dsmin):continue
        if any(_max_rect_d2(p,box)<=5000**2 for p in pos):continue
        rlo2=max([L2]+dsmin)
        if any(_max_rect_d2(z,box)<=rlo2 for z in neg):continue
        if any(_max_rect_d2(point_key(z),box)<=20000**2 for z in history.failed_clears):continue
        impossible=False
        for al,ah,bl,bh,ch in hh:
            lower=min(al*xl,al*xh,ah*xl,ah*xh)+min(bl*yl,bl*yh,bh*yl,bh*yh)
            if lower>ch:impossible=True;break
        if impossible:continue
        if _max_rect_d2(qm,box)<=rlo2:leaves+=1;continue
        if max(xh-xl,yh-yl)<=1:return {'certified':False,'reason':'unresolved_mm_cell','cells':seen}
        if xh-xl>=yh-yl:
            mid=(xl+xh)//2;stack.extend([(xl,mid,yl,yh),(mid,xh,yl,yh)])
        else:
            mid=(yl+yh)//2;stack.extend([(xl,xh,yl,mid),(xl,xh,mid,yh)])
    return {'certified':True,'cells':seen,'covered_cells':leaves,
            'scope':'continuous source set with Q1 rationalized wedges',
            'arithmetic':'integer distance bounds; enclosing Q1 Fraction coefficient intervals'}


def plan_next(history, cfg, check_budget=lambda:None):
    """Discrete Q2 model, shared byte-for-byte between the two baselines.
    Cache depends on source history, NEVER on coverage route or hidden truth.
    Grid scores are sampled lower estimates; reception checked continuously.
    """
    if history.cached_plan is not None:return history.cached_plan
    check_budget()
    sc=history.scenarios(cfg['source_samples_search'])
    scv=history.scenarios(cfg['source_samples_validate'],dense=True)
    h,c=halfplanes(history.observations); errors=np.linspace(-ALPHA,ALPHA,cfg['error_samples_search'])
    errorsv=np.linspace(-ALPHA,ALPHA,cfg['error_samples_validate'])
    obspos=np.array([o[:2] for o in history.observations]); old={point_key(o) for o in obspos} | {point_key(o) for o in history.negatives}
    rlo=np.maximum(1000.,np.linalg.norm(sc[:,None,:]-obspos[None,:,:],axis=2).max(axis=1))
    # All true C points lie in this disk, for ANY compatible sampled source.
    x0=sc[0];rad=rlo[0];lo=x0-rad;hi=x0+rad
    table={}; rejected=0
    def evaluate(points):
        nonlocal rejected
        for point in points:
            check_budget();q=snap(point);key=point_key(q)
            if key in old or key in table:continue
            if np.any(np.linalg.norm(sc-q,axis=1)>rlo+1e-8):continue
            val=float(sampled_worst(q,h,c,sc,errors))
            if math.isnan(val):rejected+=1;continue  # never interpret as zero
            table[key]=(val,q)
    v=history.outer_polygon();centre=np.mean(v,axis=0)
    # Analytic witness plus regular grid. Witnesses are candidates, not automatic winners.
    x,y,td=history.observations[0];ang=math.radians(td)
    pts=[centre]
    for step in [350.,600.,900.]:
        for da in [-60.,-45.,45.,60.]:
            t=ang+math.radians(da);pts.append(np.array([x,y])+step*np.array([math.cos(t),math.sin(t)]))
    for ds in [30.,80.,200.]:
        for direction in np.linspace(0,2*math.pi,8,endpoint=False):
            pts.append(centre+ds*np.array([math.cos(direction),math.sin(direction)]))
    grid=cfg['grid_steps_m'];g=grid[0]
    pts.extend(np.array([xx,yy]) for xx in np.arange(lo[0],hi[0]+g*.1,g)
               for yy in np.arange(lo[1],hi[1]+g*.1,g))
    evaluate(pts)
    for previous,step in zip(grid[:-1],grid[1:]):
        ranked=sorted(table.values(),key=lambda z:(z[0],np.linalg.norm(z[1]-obspos[-1])))
        seeds=[]
        for val,q in ranked:
            if not math.isfinite(val):break
            if all(np.linalg.norm(q-z)>=step*2 for z in seeds):seeds.append(q)
            if len(seeds)>=cfg['refine_centres']:break
        points=[]
        for q in seeds:
            for dx in np.arange(-previous,previous+step*.1,step):
                for dy in np.arange(-previous,previous+step*.1,step):points.append(q+[dx,dy])
        evaluate(points)
    ranked=sorted(table.values(),key=lambda z:(z[0],np.linalg.norm(z[1]-obspos[-1]),*z[1]))
    valid=[]
    for val,q in ranked[:cfg['certification_candidates']]:
        if not math.isfinite(val):continue
        check_budget();cert=certify_reception(history,q,cfg['reception_max_cells'])
        if not cert['certified']:continue
        jv=float(sampled_worst(q,h,c,scv,errorsv))
        if not math.isfinite(jv):continue
        valid.append((max(val,jv),val,jv,q,cert))
        if len(valid)>=cfg['validation_candidates']:break
    if not valid:
        # Explicit bounded candidate fallback: the repo's analytic witness ±60°/900m.
        for da in [-60.,60.]:
            t=ang+math.radians(da);q=snap(np.array([x,y])+900*np.array([math.cos(t),math.sin(t)]))
            if point_key(q) in old:continue
            cert=certify_reception(history,q,cfg['reception_max_cells'])
            val=float(sampled_worst(q,h,c,sc,errors));jv=float(sampled_worst(q,h,c,scv,errorsv))
            if cert['certified'] and math.isfinite(max(val,jv)):valid.append((max(val,jv),val,jv,q,cert))
    if not valid:raise PlanningError('No certified finite candidate in this bounded search')
    out=min(valid,key=lambda z:(z[0],np.linalg.norm(z[3]-obspos[-1]),*z[3]))
    combined,js,jv,q,cert=out
    history.cached_plan={'point':q.tolist(),'J_hat_search_m':js,'J_hat_validate_m':jv,
        'J_hat_union_m':combined,'reception_certificate':cert,
        'n_candidates_scored':len(table),'source_samples':[len(sc),len(scv)],
        'errors_samples':[len(errors),len(errorsv)],'geometry_rejections':rejected,
        'optimality':'best validated/receiver-certified candidate tested; not continuous global optimum'}
    return history.cached_plan


def warmup():
    """Compile before /enter so JIT compilation does not consume official run time."""
    h,c=halfplanes([(0.,0.,45.)]);sampled_worst(np.array([900.,0.]),h,c,np.array([[500.,500.]]),np.array([0.]))


def segment_distance(q,a,b):
    q,a,b=map(lambda z:np.asarray(z,dtype=float),(q,a,b));v=b-a;vv=float(v@v)
    t=0. if vv==0 else float(np.clip((q-a)@v/vv,0,1))
    return float(np.linalg.norm(q-(a+t*v))),t


def exact_route_certificate(points_m, max_cells=2_000_000):
    """Integer-mm proof of union-of-1000m-disks covering closed 1800m arena."""
    points=[point_key(q) for q in points_m];A=1_800_000;R2=1_000_000**2
    stack=[(-A,A,-A,A)];seen=covered=outside=0
    while stack:
        b=stack.pop();seen+=1
        if seen>max_cells:return {'certified':False,'unresolved':len(stack)+1,'cells':seen}
        if _min_rect_d2((0,0),b)>A*A:outside+=1;continue
        if any(_max_rect_d2(p,b)<=R2 for p in points):covered+=1;continue
        xl,xh,yl,yh=b
        if max(xh-xl,yh-yl)<=1:return {'certified':False,'unresolved':1,'cells':seen}
        xm=(xl+xh)//2;ym=(yl+yh)//2
        xs=[(xl,xm),(xm,xh)] if xh-xl>1 else [(xl,xh)]
        ys=[(yl,ym),(ym,yh)] if yh-yl>1 else [(yl,yh)]
        stack.extend((x0,x1,y0,y1) for x0,x1 in xs for y0,y1 in ys)
    return {'certified':True,'unresolved':0,'cells':seen,'covered':covered,'outside':outside,
            'arithmetic':'exact Python integers, actual millimetre stop coordinates'}


def regenerate_spiral(starts=10):
    """Offline-only reproduction of the 12-stop family. Never changes config.json.
    Kilometres internally, metres in output. Multi-start local SLSQP, not global proof.
    """
    from scipy.optimize import minimize
    m=11;A=1.8;B=.999;dr=.005;lo=A-B+1e-8;hi=math.sqrt(A*A-B*B)-1e-8
    def eta(r):return np.arccos(np.clip((A*A+r*r-B*B)/(2*A*r),-1,1))
    def etaprime(r):
        z=(A*A+r*r-B*B)/(2*A*r)
        return -(1-(A*A-B*B)/(r*r))/(2*A*np.sqrt(np.maximum(1-z*z,1e-30)))
    def objective(z):
        r=z[:m];g=z[m:-1]
        return r[0]+np.sqrt(np.maximum(1e-24,r[:-1]**2+r[1:]**2-2*r[:-1]*r[1:]*np.cos(g))).sum()
    def gradient(z):
        r=z[:m];g=z[m:-1];dist=np.sqrt(np.maximum(1e-24,r[:-1]**2+r[1:]**2-2*r[:-1]*r[1:]*np.cos(g)))
        j=np.zeros(2*m);j[0]=1
        j[:m-1]+=(r[:-1]-r[1:]*np.cos(g))/dist;j[1:m]+=(r[1:]-r[:-1]*np.cos(g))/dist
        j[m:-1]=r[:-1]*r[1:]*np.sin(g)/dist;return j
    def constraints(z):
        e=eta(z[:m]);return np.r_[e+np.roll(e,-1)-z[m:],np.diff(z[:m])-dr]
    def constraints_jac(z):
        j=np.zeros((2*m-1,2*m));ep=etaprime(z[:m])
        for i in range(m):j[i,i]=ep[i];j[i,(i+1)%m]=ep[(i+1)%m];j[i,m+i]=-1
        for i in range(m-1):j[m+i,i]=-1;j[m+i,i+1]=1
        return j
    records=[];best=None
    regular=A*math.cos(math.pi/m)-math.sqrt(B*B-A*A*math.sin(math.pi/m)**2)
    for seed in range(starts):
        rng=np.random.default_rng(seed)
        if seed==0:r=np.linspace(regular+.02,regular+.03+dr*(m-1),m)
        else:
            r=np.sort(rng.uniform(max(lo+.02,regular-.07),min(hi-.005,regular+.3),m))
            r=np.maximum.accumulate(r-dr*np.arange(m))+dr*np.arange(m)
            r=np.minimum(r,hi-.005-dr*(m-1-np.arange(m)))
        cap=eta(r)+np.roll(eta(r),-1);g=cap*(2*math.pi/cap.sum())
        if seed:g=np.maximum(.001,g+rng.normal(0,.03,m));g*=2*math.pi/g.sum()
        cons=[{'type':'eq','fun':lambda z:z[m:].sum()-2*math.pi,'jac':lambda z:np.r_[np.zeros(m),np.ones(m)]},
              {'type':'ineq','fun':constraints,'jac':constraints_jac}]
        res=minimize(objective,np.r_[r,g],jac=gradient,bounds=[(lo,hi)]*m+[(1e-5,2*math.asin(B/A))]*m,
                     constraints=cons,method='SLSQP',options={'ftol':1e-11,'maxiter':500})
        rr=res.x[:m]*1000;gg=res.x[m:];psi=np.r_[0,np.cumsum(gg[:-1])]
        pts=np.vstack([np.zeros(2),np.column_stack([rr*np.cos(psi),rr*np.sin(psi)])]);pts=np.round(pts,3)
        feasible=float(np.min(constraints(res.x)))>=-1e-7 and abs(gg.sum()-2*math.pi)<1e-7
        cert=exact_route_certificate(pts) if feasible else {'certified':False}
        length=float(np.linalg.norm(np.diff(pts,axis=0),axis=1).sum())
        item={'seed':seed,'optimizer_success':bool(res.success),'message':str(res.message),
              'constraints_min':float(np.min(constraints(res.x))),'equality_error':float(abs(gg.sum()-2*math.pi)),
              'points':pts.tolist(),'radii_m':rr.tolist(),'gaps_rad':gg.tolist(),
              'length_m':length,'simplified_time_s':length/5+6*(m+1),'certificate':cert}
        records.append(item)
        if cert['certified'] and (best is None or length<best['length_m']):best=item
    return {'model':'11 outer stops, nominal radial increments >=5m, 999m design disks',
            'starts':starts,'records':records,'best':best,
            'note':'Local candidate reproduction only. Frozen baseline route is NOT overwritten.'}
