# Baseline v2.0：七点六边形完整交付

本包适用于第三问的全向源。十二点螺旋模型继续使用原 Baseline v1.0，本包没有修改或替换它。

## 先阅读

- `算法模型.md`：完整数学模型，沿用 v1.0 的 0—13 节结构和 W、P、F、Omega、D、theta、beta、R_k、R_A、J、T 定义。
- `算法模型.pdf` / `算法模型.tex`：便于阅读的 PDF 和可重新编译的 LaTeX 源文件。
- `变更说明.md`：两项关键修正及完整版本差异。
- `validation/验证报告.md`：本次实际验证、逐场对照与适用范围。
- `VERSION.json`、`SHA256SUMS.json`：来源指纹和交付文件校验。

v2.0 采用极径 1200 m 的七点覆盖、当前频道优先扫描、每源首次发现后最多 3 次专用检测、C/U 选择测向或光学收尾、源任务最小增量插入与两轮任务 2-opt。源任务之间允许连续服务；不在专用测点或清除点扫描其他频道。

完整历史决定 P、Omega、F 和第二问候选。J 仍是纯测向区域的最坏直径损失；本版先复用 Q2 的一个经接收认证候选，再由 C 比较是否值得执行。光学允许失败探测，并用认证有限覆盖保证在模型条件下最终覆盖源位置。

## 环境

建议 Python 3.12。本次测试使用的确切依赖写在 `requirements-lock.txt`；通用依赖范围在 `requirements.txt`。

```bash
python -m venv .venv
```

macOS / Linux 激活：

```bash
source .venv/bin/activate
```

Windows PowerShell 激活：

```powershell
.venv\Scripts\Activate.ps1
```

安装并验证：

```bash
python -m pip install -r requirements.txt
python run.py --mode selftest --out runs/selftest_local
python run.py --mode routecheck --out runs/routecheck_local
```

运行入口仅为 `run.py`。`baseline_runtime.py` 是继承的接口和基础类模块，不是另一个 v2 控制器入口。

## 自建离线运行

默认不联网，也不调用官方模拟器：

```bash
python run.py --mode offline --seed 20260912 --out runs/offline_01
python run.py --mode offline --scene validation/paired_12/000_uniform_20260912/scene.json --out runs/replay_scene_01
python run.py --mode experiment --trials 12 --seed 20260912 --out runs/paired_12_local
python audit.py runs/paired_12_local
python compare.py --out runs/paired_exact
python audit.py runs/paired_exact
```

`compare.py` 直接读取本包保存的 v1.0 原始场景，不重新生成坐标或半径，用于严格成对比较。

每次使用新的输出目录，避免覆盖已有请求日志。自建场景包括均匀、聚集和边缘三类；它们不代表官方生成分布。误差是沿用 v1.0 的固定有界空间场，重复位置没有重新抽噪声。场景真值仅由离线环境与运行后的审计程序使用。

## 官方演练

在同一台电脑上手动启动官方演练、等待接口开放后，使用真实参赛队号：

```bash
python run.py --mode live --robot-id 你的实际参赛队号 --out runs/practice_01
```

默认地址为 `http://127.0.0.1:2026`；更换端口时用 `--url`。程序不会打开官方测试页面或启动正式测试，本次交付也没有消耗正式次数。

同一个仍有效的会话、相同源码和配置下，可按原日志恢复：

```bash
python run.py --mode live --robot-id 你的实际参赛队号 --out runs/practice_01 --resume
```

客户端保持相同请求 ID 重试，只有接受的动作才计费。恢复途中已过现实期限时，只读取剩余已确认日志来恢复真实位置/频道，再发送退出；若有结果未确定的旧请求，不越过它发送新动作。v1 日志不能交给 v2 恢复。

## 日志和保证

- `session.json`：配置、源码指纹和会话元数据。
- `actions.jsonl`：原始请求与响应，支持逐动作计时复核。
- `decisions.json`：任务顺序、C/U 分支成本、几何证书、光学序列、预算和异常原因。
- `summary.json`：实际虚拟时间、路程、检测/换频/清除次数、结束状态。

光学几何用有理数与实际毫米坐标认证；响应分箱验证全部 36,000 个合法 0.01° 读数。几何保证针对第一问实际有理化楔形模型，不能宣称是理想三角函数的形式化证明。后向任务成本使用普通浮点数，数学上界与浮点误差容差分开说明。

计划费用只覆盖当前已经列入的源与扫描动作。发现新源后重新规划，不沿用旧值作为全场未知源的总耗时上界。最多三次检测后的光学覆盖是有限的，但现实期限、虚拟期限或通信异常仍可能导致未完成；以实际响应和结束状态为准。

本包不修改 GitHub main 或 Overleaf 的论文。需要写入论文时，应使用此版验证结果并标明版本，不能把 v1.0 的结果冒充 v2.0。
