"""Certified optical policies and one-step C/U, Baseline v2.0.

The certificate concerns continuous sets defined by Q1's *rationalized*
halfplanes. It does not assert exactness of ideal transcendental geometry.
Float geometry proposes orientations/centres only: every covering cell is
checked with Fraction arithmetic against the actual millimetre command.
Terminal callbacks must themselves return upper bounds, one for each point.
"""
from __future__ import annotations

from fractions import Fraction as F
from functools import lru_cache
import math
import numpy as np

from solver import (PlanningError, History, exact_halfplanes, enclosing,
                    plan_next, point_key, snap)

NO_TERMINAL = lambda points, channel: np.zeros(len(points), dtype=float)
_ZERO = F(0)


def _fraction(x):
    if isinstance(x, F):
        return x
    if isinstance(x, (int, np.integer)):
        return F(int(x))
    if not math.isfinite(float(x)):
        raise PlanningError('Non-finite geometry')
    return F(str(float(x)))


def _rational_polygon(poly):
    out = [(_fraction(p[0]), _fraction(p[1])) for p in poly]
    if not out:
        raise PlanningError('Empty polygon is not a clearance certificate')
    return out


def _clip_exact(poly, a, b, c):
    """Closed rational halfplane intersection, including point/line sets."""
    if not poly:
        return []
    out = []
    for p, q in zip(poly, poly[1:] + poly[:1]):
        ap, aq = a*p[0] + b*p[1] - c, a*q[0] + b*q[1] - c
        if ap <= 0:
            out.append(p)
        if (ap < 0 < aq) or (aq < 0 < ap):
            t = ap/(ap-aq)
            out.append((p[0]+t*(q[0]-p[0]), p[1]+t*(q[1]-p[1])))
    unique = []
    for p in out:
        if not unique or p != unique[-1]:
            unique.append(p)
    if len(unique) > 1 and unique[0] == unique[-1]:
        unique.pop()
    return unique


@lru_cache(maxsize=8)
def _circle_normals(count=24):
    """Integer normals; ceil(norm) makes every plane contain the real disk."""
    out = []
    for j in range(count):
        angle = 2*math.pi*j/count
        a = int(round(math.cos(angle)*10**9))
        b = int(round(math.sin(angle)*10**9))
        squared = a*a+b*b
        norm = math.isqrt(squared)
        if norm*norm < squared:
            norm += 1
        out.append((F(a), F(b), F(norm)))
    return tuple(out)


def _intersect_disk_outer(poly, centre, radius):
    x, y = map(_fraction, centre)
    radius = _fraction(radius)
    for a, b, norm in _circle_normals():
        poly = _clip_exact(poly, a, b, a*x+b*y+radius*norm)
        if not poly:
            break
    return poly


def certified_outer(history, *, first_only=False, check_budget=lambda: None):
    """Outer enclosure of the complete position/radius history.

    Exact rational wedges and necessary consequences of the common R are
    intersected. Open negative/near/failed-clear holes may be omitted: this
    enlarges the set and never manufactures a false clearance guarantee.
    """
    if not history.observations:
        raise PlanningError('Optical search requires a confirmed source')
    observations = history.observations[:1] if first_only else history.observations
    poly = [(F(-1800), F(-1800)), (F(1800), F(-1800)),
            (F(1800), F(1800)), (F(-1800), F(1800))]
    poly = _intersect_disk_outer(poly, (0, 0), 1800)
    for obs in observations:
        check_budget()
        for a, b, c in exact_halfplanes([obs]):
            poly = _clip_exact(poly, a, b, c)
        poly = _intersect_disk_outer(poly, obs[:2], 1500)
    if not first_only:
        for negative in history.negatives:
            z = tuple(map(_fraction, negative))
            for obs in observations:
                p = tuple(map(_fraction, obs[:2]))
                # |X-z| > R >= |X-p|. Closing the strict bound is an outer set.
                poly = _clip_exact(poly, 2*(z[0]-p[0]), 2*(z[1]-p[1]),
                                   z[0]**2+z[1]**2-p[0]**2-p[1]**2)
    if not poly:
        raise PlanningError('Exact history outer set empty')
    return poly


def _rotation(angle):
    """A rational orthogonal matrix, not rounded sine/cosine coefficients."""
    angle = ((angle + math.pi) % (2*math.pi)) - math.pi
    # Axes are equivalent under a half turn, avoiding the tan(pi/2) pole.
    if angle > math.pi/2:
        angle -= math.pi
    if angle < -math.pi/2:
        angle += math.pi
    t = F(int(round(math.tan(angle/2)*10**9)), 10**9)
    return (1-t*t)/(1+t*t), 2*t/(1+t*t)


def _local_bounds(poly, rotation):
    co, si = rotation
    u = [co*x+si*y for x, y in poly]
    v = [-si*x+co*y for x, y in poly]
    return min(u), max(u), min(v), max(v)


def _world(u, v, rotation):
    co, si = rotation
    return co*u-si*v, si*u+co*v


def _d2(p, q):
    return (p[0]-q[0])**2+(p[1]-q[1])**2


def _snap_fraction(point):
    return tuple(F(round(x*1000), 1000) for x in point)


def _ceil_fraction(x):
    return -((-x.numerator)//x.denominator)


def _sqrt_lower(x, denominator=10**6):
    if x <= 0:
        return F(0)
    return F(math.isqrt((x.numerator*denominator**2)//x.denominator), denominator)


def _grid_shapes(bounds, radius, limit=2):
    ul, uh, vl, vh = bounds
    width, height = uh-ul, vh-vl
    safe = radius-F(1, 500)  # 2 mm geometric allowance before exact command check.
    min_rows = max(1, _ceil_fraction(height/(2*safe)))
    choices = []
    # A small finite family; this is not a claim of globally minimum disk count.
    for rows in range(min_rows, min_rows+8):
        cell_h = height/rows
        cell_w = _sqrt_lower(4*safe*safe-cell_h*cell_h)
        if cell_w <= 0:
            continue
        cols = max(1, _ceil_fraction(width/cell_w))
        choices.append((rows*cols, cols, rows))
    return [(cols, rows) for _, cols, rows in sorted(set(choices))[:limit]]


def _grid_catalog(poly, rotation, cols, rows, radius, label, check_budget):
    bounds = _local_bounds(poly, rotation)
    ul, uh, vl, vh = bounds
    grid = []
    worst = F(0)
    for row in range(rows):
        line = []
        va, vb = vl+(vh-vl)*row/rows, vl+(vh-vl)*(row+1)/rows
        for col in range(cols):
            if (row*cols+col) % 32 == 0:
                check_budget()
            ua, ub = ul+(uh-ul)*col/cols, ul+(uh-ul)*(col+1)/cols
            centre = _snap_fraction(_world((ua+ub)/2, (va+vb)/2, rotation))
            corners = [_world(u, v, rotation) for u in (ua, ub) for v in (va, vb)]
            actual = max(_d2(corner, centre) for corner in corners)
            if actual > radius*radius:
                return []
            worst = max(worst, actual)
            line.append(centre)
        grid.append(line)
    certificate = {
        'certified': True, 'method': 'rational_rectangle_cells',
        'scope': 'continuous rational outer polygon',
        'arithmetic': 'Fraction cell corners; actual millimetre commands',
        'design_radius_m': float(radius), 'max_cell_radius_sq': str(worst),
        'rows': rows, 'columns': cols, 'cells': rows*cols,
        'orientation': [str(v) for v in rotation],
        'local_bounds': [str(v) for v in bounds], 'candidate': label,
    }
    catalog = []
    for flip_rows in (False, True):
        selected = grid[::-1] if flip_rows else grid
        for first_reverse in (False, True):
            path = []
            for i, line in enumerate(selected):
                path.extend(line[::-1] if bool(i % 2) ^ first_reverse else line)
            points = np.asarray([[float(x), float(y)] for x, y in path])
            catalog.append({'points': points, 'certificate': dict(certificate)})
    return catalog


def catalog_from_polygon(poly, cfg, check_budget=lambda: None):
    """Cover a supplied polygon, rationalizing input coordinates exactly.

    The caller is responsible for its enclosure provenance. This function
    certifies coverage of that input, not that an arbitrary float polygon is F.
    """
    poly = _rational_polygon(poly)
    radius = _fraction(cfg.get('optical_radius_m', 19.9))
    if not 0 < radius < 20:
        raise PlanningError('Optical design radius must lie strictly between 0 and 20')
    max_points = int(cfg.get('optical_max_points', 20000))
    catalog = []
    check_budget()
    approx = np.asarray([[float(x), float(y)] for x, y in poly])
    centre, _ = enclosing(approx)
    centre = _snap_fraction(tuple(map(_fraction, centre)))
    actual = max(_d2(v, centre) for v in poly)
    if actual <= radius*radius:
        catalog.append({'points': np.array([[float(v) for v in centre]]),
                        'certificate': {'certified': True, 'method': 'single_disk',
                         'scope': 'continuous supplied rational polygon',
                         'arithmetic': 'Fraction vertex distances; convexity',
                         'design_radius_m': float(radius),
                         'max_cell_radius_sq': str(actual), 'cells': 1}})
    if len(approx) > 1:
        differences = approx[:, None, :] - approx[None, :, :]
        ii, jj = np.unravel_index(np.argmax(np.sum(differences*differences, axis=2)),
                                 differences.shape[:2])
        delta = approx[jj]-approx[ii]
        angle = math.atan2(delta[1], delta[0])
    else:
        angle = 0.
    rotations = list(dict.fromkeys([_rotation(angle), _rotation(0.)]))
    proposals = []
    for rotation in rotations:
        bounds = _local_bounds(poly, rotation)
        for cols, rows in _grid_shapes(bounds, radius):
            if cols*rows <= max_points:
                proposals.append((cols*rows, cols, rows, rotation))
    _, factor = _catalog_limits(cfg)
    for count, cols, rows, rotation in sorted(proposals):
        # Use only an already certified alternative for early pruning. A
        # failed small-grid proposal must never suppress the sole valid cover.
        if catalog and count > min(len(v['points']) for v in catalog)*factor+2:
            continue
        catalog.extend(_grid_catalog(poly, rotation, cols, rows, radius,
                                     'rotated_strip', check_budget))
    if not catalog:
        raise PlanningError('No finite certified optical cover within point cap')
    return _prune_catalog(_add_2opt(catalog, cfg, check_budget), cfg)


def _add_2opt(catalog, cfg, check_budget):
    """Extra fixed-endpoint path candidates; originals remain available to U."""
    out = list(catalog)
    passes = min(3, max(0, int(cfg.get('optical_2opt_passes', 1))))
    for item in catalog:
        check_budget()
        points = np.asarray(item['points']).copy()
        if len(points) < 4 or len(points) > 256:
            continue
        changed = False
        for _ in range(passes):
            distances = np.linalg.norm(points[:, None, :]-points[None, :, :], axis=2)
            left, right = np.triu_indices(len(points)-2, k=1)
            left, right = left+1, right+1
            delta = (distances[left-1, right]+distances[left, right+1]
                     -distances[left-1, left]-distances[right, right+1])
            best = int(np.argmin(delta))
            if delta[best] >= -1e-9:
                break
            a, b = int(left[best]), int(right[best])
            points[a:b+1] = points[a:b+1][::-1]
            changed = True
        if changed:
            cert = dict(item['certificate'])
            cert['path_refinement'] = 'bounded_fixed_endpoints_2opt'
            cert['path_refinement_passes'] = passes
            out.append({'points': points, 'certificate': cert})
    return out


def _deduplicate(catalog):
    out, seen = [], set()
    for item in catalog:
        key = tuple(map(point_key, item['points']))
        if key not in seen:
            out.append(item)
            seen.add(key)
    return out


def _catalog_limits(cfg):
    limit = int(cfg.get('optical_catalog_limit', 8))
    factor = float(cfg.get('optical_point_count_factor', 1.5))
    if limit < 1 or not math.isfinite(factor) or factor < 1:
        raise PlanningError('Optical catalog limit must be positive and count factor >= 1')
    return limit, factor


def _prune_catalog(catalog, cfg):
    """Deterministic finite policy subset; every retained cover stays intact.

    This heuristic may increase the best terminal-dependent cost. It cannot
    invalidate coverage because it removes whole certified policies, never
    individual points from a policy. Different starting ends get preference.
    """
    unique = _deduplicate(catalog)
    if not unique:
        raise PlanningError('Cannot prune an empty optical catalog')
    limit, factor = _catalog_limits(cfg)
    min_count = min(len(item['points']) for item in unique)
    eligible = [item for item in unique if len(item['points']) <= min_count*factor+2]

    def ordering(item):
        points = np.asarray(item['points'])
        length = float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())
        # A final coordinate sequence breaks all remaining ties independently
        # of caller traversal order; float length is only a proposal heuristic.
        return (length, len(points), point_key(points[0]),
                tuple(map(point_key, points)))

    eligible.sort(key=ordering)
    chosen, deferred, starts = [], [], set()
    for item in eligible:
        start = point_key(item['points'][0])
        if start not in starts and len(chosen) < limit:
            chosen.append(item)
            starts.add(start)
        else:
            deferred.append(item)
    chosen.extend(deferred[:limit-len(chosen)])
    return sorted(chosen, key=ordering)


def _history_key(history):
    return (tuple(tuple(o) for o in history.observations),
            tuple(tuple(o) for o in history.negatives),
            tuple(tuple(o) for o in history.failed_clears))


def optical_catalog(history, cfg, check_budget=lambda: None):
    """Catalog independent of entry position, frequency and successor."""
    key = (_history_key(history), repr(sorted(cfg.items())))
    cached = getattr(history, '_cu_catalog', None)
    if cached is not None and cached[0] == key:
        return cached[1]
    fallback_poly = certified_outer(history, first_only=True, check_budget=check_budget)
    rotation = _rotation(math.radians(float(history.observations[0][2])))
    radius = _fraction(cfg.get('optical_radius_m', 19.9))
    fallback = _grid_catalog(fallback_poly, rotation, 52, 2, radius,
                             'first_history_H0_104', check_budget)
    if not fallback:
        # 104 is a verified option, never a promise for an arbitrary rectangle.
        fallback = catalog_from_polygon(fallback_poly, cfg, check_budget)
        for item in fallback:
            item['certificate']['candidate'] = 'first_history_H0_general_fallback'
    try:
        current = certified_outer(history, check_budget=check_budget)
        catalog = catalog_from_polygon(current, cfg, check_budget)
    except (PlanningError, ArithmeticError, ValueError):
        catalog = []
    fallback = _prune_catalog(_add_2opt(fallback, cfg, check_budget), cfg)
    # Keep H0 separately even when a much smaller current cover wins pruning.
    # This is usable after anomalous observations without trusting later data.
    history._cu_initial_fallback = fallback
    catalog = _prune_catalog(catalog + fallback, cfg)
    history._cu_catalog = (key, catalog)
    return catalog


def _distance_nm_upper(p, q):
    """Upper Euclidean distance in integer nanometres for mm command points."""
    a, b = point_key(p), point_key(q)
    d2 = (a[0]-b[0])**2+(a[1]-b[1])**2
    squared = d2*10**12
    root = math.isqrt(squared)
    return root + (root*root < squared)


def _optical_entry(item, p, c, terminal):
    points = np.asarray(item['points'], dtype=float)
    tails = np.asarray(terminal(points, c), dtype=float)
    if tails.shape != (len(points),) or np.any(np.isnan(tails)) or np.any(tails < 0):
        raise PlanningError('Terminal must return one nonnegative bound per point')
    length = _distance_nm_upper(p, points[0])
    costs = []
    for i, q in enumerate(points):
        if i:
            length += _distance_nm_upper(points[i-1], q)
        travel = math.nextafter(length/5_000_000_000, math.inf)
        prefix = math.nextafter(travel+3*(i+1)+2, math.inf)
        costs.append(math.nextafter(prefix+float(tails[i]), math.inf))
    return {'kind': 'optical', 'points': points,
            'certificate': item['certificate'], 'bound_s': max(costs),
            'prefix_bounds_s': np.asarray(costs), 'channel': int(c)}


def optical_value(catalog, p, c, terminal=NO_TERMINAL):
    """max over *all* possible first-success positions, for a general terminal."""
    if not catalog:
        raise PlanningError('Empty optical catalog')
    return min((_optical_entry(item, p, c, terminal) for item in catalog),
               key=lambda item: (item['bound_s'], len(item['points'])))


def bearing_bin_index(theta, width=4.):
    n = int(round(360./width))
    if width <= 0 or abs(n*width-360.) > 1e-10:
        raise PlanningError('Bearing bins must partition 360 degrees')
    return min(n-1, int((float(theta) % 360.)/width))


def _bin_outer(poly, point, index, width):
    # Inclusion is checked against every legal centidegree response below.
    centre = (index+.5)*width
    for a, b, c in exact_halfplanes([(*map(float, point), centre)],
                                  error_deg=1.+width/2.):
        poly = _clip_exact(poly, a, b, c)
    return poly


@lru_cache(maxsize=16)
def _certify_direction_bins(width, resolution):
    """Finite enumeration of every legal interface response, NOT sampling."""
    n = int(round(360./width))
    count = int(round(360./resolution))
    if (width <= 0 or resolution <= 0 or abs(n*width-360.) > 1e-9
            or abs(count*resolution-360.) > 1e-9):
        raise PlanningError('Invalid bearing partition or response resolution')
    planes = [exact_halfplanes([(0., 0., (i+.5)*width)],
                              error_deg=1.+width/2.) for i in range(n)]
    # Each rational wedge is generated by its two forward boundary rays.
    for j in range(count):
        theta = round(j*resolution, 12)
        index = bearing_bin_index(theta, width)
        h = exact_halfplanes([(0., 0., theta)])
        rays = []
        for a, b, _ in h:
            for ray in ((-b, a), (b, -a)):
                if all(aa*ray[0]+bb*ray[1] <= 0 for aa, bb, _ in h):
                    rays.append(ray)
        if len(rays) != 2 or any(a*x+b*y > 0 for x, y in rays
                                for a, b, _ in planes[index]):
            raise PlanningError('A legal rational bearing wedge escapes its bin')
    return {'certified': True, 'bins': n, 'width_deg': width,
            'response_resolution_deg': resolution, 'responses_checked': count,
            'method': 'exhaustive legal responses; Fraction ray inclusion'}


def prepare_geometry(cfg):
    """Call before /enter: certify the complete finite bearing-response alphabet."""
    return _certify_direction_bins(float(cfg.get('bearing_bin_deg', 4.)),
                                   float(cfg.get('bearing_resolution_deg', .01)))


def radio_catalog(history, cfg, check_budget=lambda: None):
    """History-only Q2 candidate and posterior cover catalogs for routing DP."""
    key = (_history_key(history), repr(sorted(cfg.items())))
    cached = getattr(history, '_cu_radio_catalog', None)
    if cached is not None and cached[0] == key:
        return cached[1]
    try:
        check_budget()
        old_q2_history = getattr(history, '_cu_q2_history_key', None)
        if old_q2_history is not None and old_q2_history != key[0]:
            history.cached_plan = None
        plan = plan_next(history, cfg, check_budget)
        history._cu_q2_history_key = key[0]
        point = snap(plan['point'])
        if not plan.get('reception_certificate', {}).get('certified', False):
            raise PlanningError('Measurement candidate lacks continuous reception proof')
        width = float(cfg.get('bearing_bin_deg', 4.))
        bin_certificate = prepare_geometry(cfg)
        poly = certified_outer(history, check_budget=check_budget)
        branches = {}
        for index in range(bin_certificate['bins']):
            check_budget()
            posterior_outer = _bin_outer(poly, point, index, width)
            if not posterior_outer:
                continue
            branches[index] = catalog_from_polygon(posterior_outer, cfg, check_budget)
        result = {'point': point, 'branches': branches,
                  'bin_certificate': bin_certificate, 'q2_plan': plan}
    except (PlanningError, ArithmeticError, ValueError):
        result = None
    history._cu_radio_catalog = (key, result)
    return result


def choose_action(history, p, c, k, remaining, cfg, terminal=NO_TERMINAL,
                  check_budget=lambda: None):
    """One certified Q2 candidate versus saved finite optical policies.

    Q2 J is unchanged; optical cost only selects whether to use its returned
    point. r>0 does not pretend to solve an r-level observation tree.
    """
    optical = optical_value(optical_catalog(history, cfg, check_budget), p, c, terminal)
    if remaining <= 0:
        return optical
    radio = radio_catalog(history, cfg, check_budget)
    if radio is not None:
        point = radio['point']
        branches = {index: optical_value(catalog, point, k, terminal)
                    for index, catalog in radio['branches'].items()}
        # Near is deliberately retained even when not proved possible. This is
        # conservative and avoids discarding a branch using float distances.
        near_tail = float(np.asarray(terminal(np.asarray([point]), k))[0])
        if math.isnan(near_tail) or near_tail < 0:
            raise PlanningError('Invalid near terminal bound')
        near_cost = math.nextafter(5.+near_tail, math.inf)
        after = max([near_cost]+[item['bound_s'] for item in branches.values()])
        travel = math.nextafter(_distance_nm_upper(p, point)/5_000_000_000, math.inf)
        initial = math.nextafter(travel+int(c != k)+5., math.inf)
        total = math.nextafter(initial+after, math.inf)
        if total < optical['bound_s']:
            return {'kind': 'measure', 'point': point, 'bound_s': total,
                    'branches': branches, 'near_cost': near_cost,
                    'measurement_cost_s': initial, 'q2_plan': radio['q2_plan'],
                    'bin_certificate': radio['bin_certificate'],
                    'fallback': optical, 'channel': int(k)}
    return optical
