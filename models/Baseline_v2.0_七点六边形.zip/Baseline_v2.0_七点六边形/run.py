#!/usr/bin/env python3
"""Baseline v2.0: seven anchors, C/U service, finite insertion and 2-opt.

Offline is the default. No official test is started by this program.
The v1 numerical Q2 module is reused; the spiral v1 package is untouched.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
import time
import unittest
import numpy as np

from baseline_runtime import (JournalClient, LiveBackend, OfflineBackend,
    Channel, Controller as V1Controller, BudgetStop, ProtocolError,
    UncertainAction, synthetic_scene, save_json, jsonable)
from solver import PlanningError, snap, point_key, exact_route_certificate, warmup
from cu import (optical_catalog, optical_value, choose_action, radio_catalog,
                prepare_geometry, bearing_bin_index)
from routing import PlanEvaluator, optimize_tasks

HERE = Path(__file__).resolve().parent


class Controller(V1Controller):
    """Controller reads only accepted interface observations, never scene truth."""
    def __init__(self, client, config):
        super().__init__(client, config)
        self.optimizations = 0
        self.source_services = 0

    def clear(self, k, p, reason, certificate=None, allow_failure=False):
        reply = self.client.call('/clear', p, k)
        success = reply['clear_result'] == 'success'
        self.event('clear', channel=k, point=snap(p), reason=reason,
                   success=success, certificate=certificate)
        ch = self.channels[k]
        if success:
            ch.state = 'CLEARED'
            ch.reason = ''
        else:
            ch.history.failed_clears.append(snap(p).tolist())
            ch.history.cached_plan = None
            if not allow_failure:
                self.unresolved(k, 'certified_single_clear_failed')
        return success

    def scan_anchor(self, i):
        self.current_anchor = i
        pending = [k for k, ch in self.channels.items()
                   if ch.state == 'UNKNOWN' and i not in ch.anchors]
        if not pending:
            return
        c = self.client.channel
        order = ([c] if c in pending else []) + sorted(k for k in pending if k != c)
        self.event('anchor_start', index=i, point=self.route[i], channels=order)
        for k in order:
            self.measure(k, self.route[i], 'anchor_scan')
            self.channels[k].anchors.append(i)
        self.event('anchor_end', index=i)
        self.certify_absent()

    def certify_absent(self):
        needed = set(range(len(self.route)))
        for k, ch in self.channels.items():
            if ch.state == 'UNKNOWN' and set(ch.anchors) == needed:
                ch.state = 'EMPTY_CERTIFIED'
                self.event('absent_certified', channel=k)

    def pending_searches(self):
        return [i for i in range(len(self.route)) if any(
            ch.state == 'UNKNOWN' and i not in ch.anchors
            for ch in self.channels.values())]

    def execute_optical(self, k, plan):
        self.event('optical_start', channel=k, points=len(plan['points']),
                   bound_s=plan['bound_s'], planned_points=plan['points'],
                   certificate=plan.get('certificate'))
        # A failed attempt is an expected information branch. No radio resumes.
        for q in plan['points']:
            if self.clear(k, q, 'certified_optical_cover',
                          plan.get('certificate'), allow_failure=True):
                return
        self.unresolved(k, 'exhausted_certified_cover_without_success')

    def service(self, k, terminal):
        ch = self.channels[k]
        started = self.client.virtual_time
        self.source_services += 1
        saved = None
        initial_bound = None
        bound_valid = True
        self.event('service_start', channel=k, followups=ch.followups)
        while ch.state == 'FOUND':
            self.client.check_budget()
            prior_catalog = optical_catalog(ch.history, self.cfg, self.client.check_budget)
            try:
                action = choose_action(ch.history, self.client.p, self.client.channel,
                    k, self.cfg['max_followups'] - ch.followups, self.cfg,
                    terminal, self.client.check_budget)
            except PlanningError as exc:
                action = optical_value(prior_catalog, self.client.p,
                                       self.client.channel, terminal)
                self.event('local_planning_fallback', channel=k, reason=str(exc))
            if saved is not None and action['bound_s'] > saved['bound_s'] + 1e-8:
                action = saved
                self.event('saved_policy_retained', channel=k, bound_s=action['bound_s'])
            if initial_bound is None:
                initial_bound = action['bound_s']
            self.event('cu_decision', channel=k, decision=action['kind'],
                remaining=self.cfg['max_followups'] - ch.followups,
                bound_s=action['bound_s'], point=action.get('point'),
                branch_count=len(action.get('branches', {})),
                branch_bounds_s={b:v['bound_s'] for b,v in action.get('branches',{}).items()},
                measurement_cost_s=action.get('measurement_cost_s'),
                near_cost_s=action.get('near_cost'),
                q2_plan=action.get('q2_plan'),
                bin_certificate=action.get('bin_certificate'))
            if action['kind'] == 'optical':
                self.execute_optical(k, action)
                break
            if ch.followups >= self.cfg['max_followups']:
                raise PlanningError('C selected radio after the lifetime limit')
            outcome = self.measure(k, action['point'], 'target_followup')
            if ch.state != 'FOUND':
                break  # near invokes a separate immediate /clear at this position.
            if outcome == 'no_signal':
                # Keep the earlier valid enclosure: a contradicted receiver
                # certificate must not silently delete the true source.
                bound_valid = False
                self.event('model_anomaly', channel=k, reason='certified_receiver_no_signal')
                self.execute_optical(k, optical_value(prior_catalog, self.client.p,
                                                     self.client.channel, terminal))
                break
            theta = ch.history.observations[-1][2]
            branch_id = bearing_bin_index(theta, self.cfg['bearing_bin_deg'])
            branches = action['branches']
            saved = branches.get(branch_id, branches.get(str(branch_id)))
            if saved is None:
                bound_valid = False
                self.event('model_anomaly', channel=k, reason='uncovered_response_bin', theta=theta)
                self.execute_optical(k, optical_value(prior_catalog, self.client.p,
                                                     self.client.channel, terminal))
                break
        suffix_cost = float(np.asarray(terminal(self.client.p.reshape(1, 2),
                                                self.client.channel)).reshape(-1)[0])
        realized = self.client.virtual_time - started + suffix_cost
        if ch.state == 'CLEARED' and bound_valid and initial_bound is not None:
            if realized > initial_bound + 1e-5:
                raise PlanningError('Executed source service exceeded its saved certified budget')
        self.event('service_end', channel=k, state=ch.state,
            source_time_s=self.client.virtual_time-started,
            frozen_suffix_cost_s=suffix_cost, initial_bound_s=initial_bound,
            realized_with_frozen_suffix_s=realized, bound_valid=bound_valid)

    def replan(self):
        pending = self.pending_searches()
        found = sorted((k for k, ch in self.channels.items() if ch.state == 'FOUND'),
                       key=lambda k: (self.channels[k].discovery, k))
        catalogs = {}
        radio_catalogs = {}
        for k in found:
            try:
                catalogs[k] = optical_catalog(self.channels[k].history, self.cfg,
                                              self.client.check_budget)
                if self.channels[k].followups < self.cfg['max_followups']:
                    radio = radio_catalog(self.channels[k].history, self.cfg,
                                          self.client.check_budget)
                    if radio is not None:
                        radio_catalogs[k] = radio
            except PlanningError as exc:
                self.unresolved(k, str(exc))
        found = [k for k in found if k in catalogs]
        scan_sets = {i: [k for k, ch in self.channels.items()
                       if ch.state == 'UNKNOWN' and i not in ch.anchors] for i in pending}
        result = optimize_tasks(self.client.p, self.client.channel, pending, found,
            catalogs, self.route, scan_sets, self.cfg, self.client.check_budget,
            radio_catalogs=radio_catalogs)
        self.optimizations += 1
        tasks = result['tasks']
        self.event('global_plan', **result,
                   scope='current_listed_tasks_and_scans; excludes_future_discovered_source_service')
        evaluator = PlanEvaluator(tasks, catalogs, self.route, scan_sets, self.cfg,
                                  radio_catalogs=radio_catalogs)
        return tasks, evaluator

    def run(self):
        self.cert = exact_route_certificate(self.route)
        if not self.cert['certified']:
            raise PlanningError('Seven-point route has no continuous coverage certificate')
        self.client.call('/enter')
        self.reason = 'running'
        try:
            self.scan_anchor(0)
            while self.client.successes < 16:
                self.certify_absent()
                if all(ch.state in ('CLEARED', 'EMPTY_CERTIFIED', 'UNRESOLVED')
                       for ch in self.channels.values()):
                    break
                tasks, evaluator = self.replan()
                if not tasks:
                    break
                kind, key = tasks[0]
                if kind == 'search':
                    self.scan_anchor(key)
                else:
                    self.service(key, evaluator.suffix(1))
            complete = self.client.successes == 16 or all(
                ch.state in ('CLEARED', 'EMPTY_CERTIFIED') for ch in self.channels.values())
            self.reason = 'completed' if complete else 'incomplete_unresolved'
        except BudgetStop as exc:
            self.reason = f'budget_stop:{exc}'
        except PlanningError as exc:
            self.reason = f'planning_stopped:{exc}'
        except (ProtocolError, UncertainAction):
            self.reason = 'communication_stopped'
            raise
        finally:
            if self.reason != 'communication_stopped' and not self.client.pending:
                try:
                    if self.client.drain_confirmed_replay_for_exit():
                        ended = self.client.cursor > 0 and self.client.records[self.client.cursor-1]['path']=='/exit'
                        if not ended:
                            self.client.call('/exit')
                    else:
                        self.reason += ';exit_not_sent_pending_record'
                except ProtocolError:
                    self.reason += ';exit_not_confirmed'
        return self.summary()

    def summary(self):
        result = super().summary()
        if self.client.successes == 16:
            # The source-count upper bound independently certifies completion;
            # do not pretend that every remaining channel had seven scans.
            result['unresolved_channels'] = [k for k, ch in self.channels.items()
                if ch.state in ('FOUND', 'UNRESOLVED')]
            result['unscanned_channels_excluded_by_count'] = [
                k for k, ch in self.channels.items() if ch.state == 'UNKNOWN']
            result['completion_certificate'] = '16_distinct_successes; N<=16'
        else:
            result['completion_certificate'] = 'all_cleared_or_seven_point_absence' if self.reason == 'completed' else None
        result.update(version='baseline-v2.0', optimizations=self.optimizations,
                      source_services=self.source_services,
                      max_followups=self.cfg['max_followups'])
        return result


def run_case(cfg, out, scene=None, live=False, robot_id='offline-v2', url='', resume=False):
    backend = LiveBackend(url, cfg['http_timeout_s'], cfg['http_retries']) if live else OfflineBackend(scene)
    client = JournalClient(backend, out, robot_id, cfg, resume=resume, live=live)
    controller = Controller(client, cfg)
    start = time.monotonic()
    try:
        summary = controller.run()
        if not live:
            summary['offline_evaluation'] = backend.evaluation()
            save_json(Path(out)/'scene.json', scene)
        summary['wall_elapsed_s'] = time.monotonic()-start
        save_json(Path(out)/'summary.json', summary)
        return summary
    finally:
        save_json(Path(out)/'decisions.json', controller.events)
        client.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['offline','experiment','live','routecheck','selftest'], default='offline')
    parser.add_argument('--config', default=str(HERE/'config.json'))
    parser.add_argument('--out', default='runs/offline_v2')
    parser.add_argument('--seed', type=int, default=20260912)
    parser.add_argument('--kind', choices=['uniform','clustered','rim'], default='uniform')
    parser.add_argument('--trials', type=int, default=12)
    parser.add_argument('--scene')
    parser.add_argument('--robot-id')
    parser.add_argument('--url', default='http://127.0.0.1:2026')
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    cfg = json.loads(Path(args.config).read_text(encoding='utf-8'))
    out = Path(args.out)
    if args.mode == 'selftest':
        suite = unittest.defaultTestLoader.discover(str(HERE), pattern='test_*.py')
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        out.mkdir(parents=True, exist_ok=True)
        save_json(out/'tests.json', dict(tests=result.testsRun, failures=len(result.failures),
                  errors=len(result.errors), passed=result.wasSuccessful()))
        raise SystemExit(0 if result.wasSuccessful() else 1)
    if args.mode == 'routecheck':
        cert = exact_route_certificate(np.asarray(cfg['points']))
        out.mkdir(parents=True, exist_ok=True)
        save_json(out/'route_certificate.json', cert)
        print(json.dumps(cert, ensure_ascii=False))
        return
    warmup()
    prepare_geometry(cfg)  # Static exhaustive response proof, before /enter.
    if args.mode == 'experiment':
        out.mkdir(parents=True, exist_ok=True)
        rows = []
        for i in range(args.trials):
            kind = ['uniform','clustered','rim'][i % 3]
            scene = synthetic_scene(args.seed+i, kind)
            result = run_case(cfg, out/f'{i:03d}_{kind}_{args.seed+i}', scene)
            e = result['offline_evaluation']
            row = dict(trial=i, seed=args.seed+i, kind=kind, completion=result['completion'],
                       **{k:e[k] for k in ['actual_source_count','actual_cleared_count','clearance_ratio',
                           'virtual_time_s','movement_m','measures','switches','clear_attempts']},
                       wall_elapsed_s=result['wall_elapsed_s'])
            rows.append(row)
            with (out/'results.csv').open('w', newline='', encoding='utf-8') as f:
                writer=csv.DictWriter(f, fieldnames=list(row)); writer.writeheader(); writer.writerows(rows)
            print(json.dumps(row, ensure_ascii=False), flush=True)
        save_json(out/'experiment_summary.json', dict(version=cfg['version'], trials=rows))
        raise SystemExit(0 if all(r['completion']=='completed' for r in rows) else 1)
    if args.mode == 'live' and not args.robot_id:
        parser.error('--mode live requires your actual --robot-id')
    if args.resume and args.mode != 'live':
        parser.error('offline restart is a fresh deterministic run; use a new output directory')
    scene = json.loads(Path(args.scene).read_text()) if args.scene else synthetic_scene(args.seed,args.kind)
    result = run_case(cfg, out, scene, args.mode=='live', args.robot_id or 'offline-v2', args.url,args.resume)
    print(json.dumps(jsonable(result), ensure_ascii=False, indent=2))
    raise SystemExit(0 if result['completion']=='completed' else 1)


if __name__ == '__main__':
    main()
